# Images

Drop files here with these exact names. Anything missing shows a placeholder, so you can add them one at a time.

## Profile — /public/images/profile/
hero.jpg      Home hero portrait (4:5)
about.jpg     About page portrait (3:4)
headshot.jpg  About page photo (3:4)
casual.jpg    Home "short version" photo (3:4)
work.jpg      About page photo (4:3)

## Projects — /public/images/projects/<slug>/
Every project uses `hero.jpg` (card + case study hero) plus numbered gallery images:
01.jpg, 02.jpg, 03.jpg ...

Slugs: bassthalk, elhesa, studyhub, seagate, booklet, skilled, rlvnt, systems

Which numbers each project expects (and their layout) is set in `data/projects.ts` → `gallery`.
To add more images, add paths to a gallery block or add a new block:

  { layout: 'three', images: ['/images/projects/bassthalk/11.jpg', '.../12.jpg', '.../13.jpg'], caption: 'More work' }

Layouts: full | two | three | screenshot | mobile | dashboard

Tips: export JPGs around 2000px wide (mobile screenshots ~1080px wide). Next.js optimizes and lazy-loads them automatically.
To use .png or .webp, just change the extension in data/projects.ts.
