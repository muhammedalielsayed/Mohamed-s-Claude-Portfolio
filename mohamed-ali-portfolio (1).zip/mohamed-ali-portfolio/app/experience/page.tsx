import type { Metadata } from 'next';
import Link from 'next/link';
import PageHeader from '@/components/PageHeader';
import ExperienceTimeline from '@/components/ExperienceTimeline';
import ContactSection from '@/components/ContactSection';

export const metadata: Metadata = {
  title: 'Experience',
  description: 'From customer-facing work and printing to account management at ELHESA.',
};

export default function ExperiencePage() {
  return (
    <>
      <PageHeader
        label="Experience"
        title="Experience"
        intro={<p>It didn&apos;t follow a straight line. Each step came from a problem the last one left open.</p>}
        aside={<p>No exact dates here on purpose. The order is real. The lessons are the useful part.</p>}
      />
      <section className="page pb-20 md:pb-28" aria-label="Timeline">
        <ExperienceTimeline />
        <div className="border-t border-ink pt-8">
          <Link href="/case-studies" className="t-meta link-u">
            Read the case studies
          </Link>
        </div>
      </section>
      <ContactSection />
    </>
  );
}
