import type { Metadata } from 'next';
import { contactHref, site } from '@/data/site';

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Have a problem worth solving?',
};

const rows = [
  { kind: 'email' as const, label: 'Email' },
  { kind: 'linkedin' as const, label: 'LinkedIn' },
  { kind: 'instagram' as const, label: 'Instagram' },
];

export default function ContactPage() {
  return (
    <section className="page pb-24 pt-10 md:pb-36 md:pt-16" aria-labelledby="contact-page-title">
      <p className="t-meta flex items-center gap-2 border-b border-line pb-4 text-muted">
        <span className="square" aria-hidden />
        Contact
      </p>
      <h1 id="contact-page-title" className="t-hero mt-10 max-w-[12ch] md:mt-14">
        Have a problem worth solving?
      </h1>
      <p className="t-lead mt-10 max-w-[30ch] text-muted md:mt-14">Projects, interesting problems, collaborations, good conversations.</p>

      <ul className="mt-14 border-t border-ink md:mt-20">
        {rows.map((r) => {
          const href = contactHref(r.kind);
          const external = r.kind !== 'email';
          return (
            <li key={r.kind} className="border-b border-line">
              <a
                href={href ?? '#'}
                {...(href && external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                className="group grid grid-cols-4 items-baseline gap-4 py-6 md:grid-cols-12 md:gap-6 md:py-8"
              >
                <span className="t-meta col-span-4 text-muted md:col-span-3">{r.label}</span>
                <span className="col-span-4 break-all text-[clamp(1.6rem,4vw,3.4rem)] font-extrabold leading-none tracking-[-0.04em] transition-colors group-hover:text-accent-ink md:col-span-8">
                  {site.contact[r.kind]}
                </span>
                <span aria-hidden className="hidden text-right text-[1.6rem] transition-transform duration-300 group-hover:translate-x-1 md:col-span-1 md:block">
                  ↗
                </span>
              </a>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
