import type { Metadata } from 'next';
import Link from 'next/link';
import PageHeader from '@/components/PageHeader';
import WorkGrid from '@/components/WorkGrid';
import ContactSection from '@/components/ContactSection';
import { projects, otherWork } from '@/data/projects';

export const metadata: Metadata = {
  title: 'Work',
  description: 'Case studies across education, logistics, digital products, agencies, a clothing brand and internal systems.',
};

export default function WorkPage() {
  return (
    <>
      <PageHeader
        label="Work"
        title="Work"
        intro={<p>Marketing was where it started. The work kept turning into something else.</p>}
        aside={
          <p>
            Eight case studies. Numbers only where they&apos;re documented.{' '}
            <Link href="/case-studies" className="link-u text-ink">
              View as index
            </Link>
          </p>
        }
      />
      <section className="page pb-24 md:pb-36" aria-label="Case studies">
        <WorkGrid projects={projects} />
      </section>

      <section aria-labelledby="other-title" className="page border-t border-line py-20 md:py-28">
        <div className="grid-page gap-y-8">
          <p className="t-meta col-span-4 text-muted md:col-span-3 md:pt-3">Also along the way</p>
          <div className="col-span-4 md:col-span-9">
            <h2 id="other-title" className="t-h2">
              Other accounts
            </h2>
            <p className="t-body mt-6 text-muted">{otherWork.intro}</p>
          </div>
          <ul className="col-span-4 border-t border-ink md:col-span-9 md:col-start-4">
            {otherWork.accounts.map((a) => (
              <li key={a} className="flex items-baseline justify-between border-b border-line py-4">
                <span className="text-[clamp(1.4rem,2.6vw,2.2rem)] font-extrabold uppercase tracking-[-0.03em]">{a}</span>
                <span className="t-meta text-muted">Worked on / contributed to</span>
              </li>
            ))}
          </ul>
          <div className="col-span-4 md:col-span-9 md:col-start-4">
            <p className="t-meta mb-4 text-muted">Industries</p>
            <ul className="flex flex-wrap gap-2">
              {otherWork.industries.map((i) => (
                <li key={i} className="chip">
                  {i}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
      <ContactSection title="Have a problem worth solving?" />
    </>
  );
}
