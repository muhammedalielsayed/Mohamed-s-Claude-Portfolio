import type { MetadataRoute } from 'next';
import { projects } from '@/data/projects';
import { site } from '@/data/site';

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ['', '/about', '/work', '/case-studies', '/experience', '/skills', '/contact'];
  return [
    ...pages.map((p) => ({ url: `${site.url}${p}` })),
    ...projects.map((p) => ({ url: `${site.url}/case-studies/${p.slug}` })),
  ];
}
