import type { Metadata } from 'next';
import PageHeader from '@/components/PageHeader';
import SkillsGrid from '@/components/SkillsGrid';
import WorkAcross from '@/components/WorkAcross';
import ContactSection from '@/components/ContactSection';

export const metadata: Metadata = {
  title: 'Skills',
  description: 'Strategy, content, business, systems and account management.',
};

export default function SkillsPage() {
  return (
    <>
      <PageHeader
        label="Skills"
        title="Skills"
        intro={<p>Learned on the job, mostly. Listed honestly.</p>}
        aside={<p>These come from real work across agencies, platforms and my own project. Some are stronger than others.</p>}
      />
      <section className="page pb-24 md:pb-32" aria-label="Skill groups">
        <SkillsGrid />
      </section>
      <WorkAcross />
      <ContactSection />
    </>
  );
}
