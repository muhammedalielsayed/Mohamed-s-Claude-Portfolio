import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="page pb-32 pt-16">
      <p className="t-meta border-b border-line pb-4 text-muted">404</p>
      <h1 className="t-hero mt-12">Not here.</h1>
      <p className="t-lead mt-8 max-w-[30ch] text-muted">This page doesn&apos;t exist. The work does.</p>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link href="/work" className="btn btn-solid">
          View work
        </Link>
        <Link href="/" className="btn btn-line">
          Home
        </Link>
      </div>
    </section>
  );
}
