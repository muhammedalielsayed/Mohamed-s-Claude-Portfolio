import type { Metadata } from 'next';
import Link from 'next/link';
import SmartImage from '@/components/SmartImage';
import ProcessSection from '@/components/ProcessSection';
import ExperienceTimeline from '@/components/ExperienceTimeline';
import FutureSection from '@/components/FutureSection';
import ContactSection from '@/components/ContactSection';
import { Reveal, ImageReveal } from '@/components/Reveal';
import { site } from '@/data/site';
import { otherWork } from '@/data/projects';

export const metadata: Metadata = {
  title: 'About',
  description: "I didn't really follow a career path. I followed problems.",
};

function Chapter({ label, title, children }: { label: string; title: string; children: React.ReactNode }) {
  return (
    <section className="page" aria-label={label}>
      <div className="grid-page gap-y-6 border-t border-line py-14 md:py-24">
        <div className="col-span-4 md:col-span-3">
          <p className="t-meta text-muted md:sticky md:top-[calc(var(--nav-h)+2rem)]">{label}</p>
        </div>
        <div className="col-span-4 md:col-span-8 md:col-start-5">
          <Reveal>
            <h2 className="t-h3">{title}</h2>
            <div className="mt-8 space-y-5">{children}</div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

const didList = [
  "I've made content.",
  "I've handled customers.",
  "I've worked on campaigns.",
  "I've built workflows.",
  "I've worked with spreadsheets.",
  "I've dealt with messy problems.",
  "I've also tried building a business of my own.",
];

export default function AboutPage() {
  return (
    <>
      {/* Who I am */}
      <header className="page pb-10 pt-10 md:pt-16">
        <p className="t-meta flex items-center gap-2 border-b border-line pb-4 text-muted">
          <span className="square" aria-hidden />
          About / Who I am
        </p>
        <div className="grid-page mt-10 gap-y-10 md:mt-14">
          <div className="col-span-4 md:col-span-7">
            <h1 className="t-hero">
              I followed
              <br />
              problems.
            </h1>
            <div className="mt-10 max-w-[34ch] space-y-4 md:mt-14">
              <p className="t-lead">I didn&apos;t really follow a career path.</p>
              <p className="t-lead text-muted">
                A customer support problem led me somewhere. A content problem led me somewhere else. A marketing problem taught me
                strategy. A team problem taught me systems.
              </p>
              <p className="t-body pt-2">
                And somewhere along the way, I realized I enjoy figuring things out more than I enjoy staying inside one job description.
              </p>
            </div>
          </div>
          <div className="col-span-4 md:col-span-4 md:col-start-9">
            <ImageReveal className="relative aspect-[3/4] w-full">
              <SmartImage src={site.images.about} alt="Mohamed Ali" sizes="(min-width: 768px) 33vw, 100vw" priority hint="about.jpg" />
            </ImageReveal>
            <dl className="mt-5 grid grid-cols-2 gap-4">
              <div className="border-t border-line pt-2">
                <dt className="t-meta text-muted">Based in</dt>
                <dd className="mt-1 text-[15px] font-medium">{site.location}</dd>
              </div>
              <div className="border-t border-line pt-2">
                <dt className="t-meta text-muted">Now</dt>
                <dd className="mt-1 text-[15px] font-medium">
                  {site.currentRole}, {site.currentCompany}
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </header>

      <Chapter label="How I started" title="Not in marketing.">
        <p className="t-body">I started working very young. My first jobs had nothing to do with marketing.</p>
        <p className="t-body">
          One of them was near an English lesson. I was saving for football boots and gloves. That was the whole business plan.
        </p>
        <p className="t-body">
          In secondary school I worked at a printing place run by friends. Customer handling, basic production, and a lesson that stuck:
          understand what the customer actually wants, not only what they asked for.
        </p>
        <p className="t-body">
          At university I joined Bassthalk as customer support. Students, parents, teachers. I became one of the stronger members of the
          team and later worked on moderation and team responsibilities.
        </p>
      </Chapter>

      <Chapter label="How I learned" title="Mostly by doing it wrong first.">
        <p className="t-body">
          I joined a marketing agency knowing very little about marketing. Most of what I know came from real work: trying things, seeing
          what worked, seeing what failed.
        </p>
        <p className="t-body">
          At Pixel, when the manager left, I was asked to take on something close to a mini art director role. I had basic CapCut, limited
          Photoshop, and I&apos;m color-blind. I said yes anyway. The company eventually closed. I learned a lot before it did.
        </p>
        <p className="t-body">
          Theory without application doesn&apos;t stay with me. Real problems do. I learn by building, testing and fixing.
        </p>
      </Chapter>

      <Chapter label="What I worked on" title="Students, teachers, clients, teams, businesses, platforms.">
        <ul className="border-t border-ink">
          {didList.map((l) => (
            <li key={l} className="border-b border-line py-3 text-[1.1em]">
              {l}
            </li>
          ))}
        </ul>
        <p className="t-lead pt-4">
          Some things worked.
          <br />
          Some didn&apos;t.
          <br />
          I&apos;m still learning.
        </p>
        <div className="pt-6">
          <p className="t-meta text-muted">Industries I&apos;ve worked across</p>
          <ul className="mt-4 flex flex-wrap gap-2">
            {otherWork.industries.map((i) => (
              <li key={i} className="chip">
                {i}
              </li>
            ))}
          </ul>
        </div>
        <Link href="/work" className="t-meta link-u inline-block pt-4">
          See the work
        </Link>
      </Chapter>

      <div className="border-t border-line">
        <ProcessSection />
      </div>

      <Chapter label="What I'm learning" title="Business, and what's underneath software.">
        <p className="t-body">
          How money moves. How customers move. How teams move. How information moves. That&apos;s the part of business I keep coming back to.
        </p>
        <p className="t-body">
          On the software side, I&apos;m not an engineer and I don&apos;t claim to be. I test platforms, translate requirements and work with
          technical teams, and I want to understand more of what&apos;s happening underneath.
        </p>
      </Chapter>

      <section className="page" aria-label="Photos">
        <div className="grid-page gap-y-4 border-t border-line py-14 md:py-24">
          <ImageReveal className="relative col-span-2 aspect-[3/4] md:col-span-4 md:col-start-2">
            <SmartImage src={site.images.headshot} alt="Mohamed Ali, headshot" sizes="(min-width: 768px) 33vw, 50vw" hint="headshot.jpg" />
          </ImageReveal>
          <ImageReveal delay={0.1} className="relative col-span-2 mt-16 aspect-[3/4] md:col-span-5 md:col-start-7 md:mt-32 md:aspect-[4/3]">
            <SmartImage src={site.images.work} alt="Mohamed Ali at work" sizes="(min-width: 768px) 42vw, 50vw" hint="work.jpg" />
          </ImageReveal>
        </div>
      </section>

      <div className="border-t border-line">
        <FutureSection />
      </div>

      <section aria-labelledby="about-timeline" className="page border-t border-line py-20 md:py-28">
        <div className="grid-page gap-y-6">
          <p className="t-meta col-span-4 text-muted md:col-span-3 md:pt-3">Career timeline</p>
          <h2 id="about-timeline" className="t-h2 col-span-4 md:col-span-9">
            Where I&apos;ve been
          </h2>
        </div>
        <div className="mt-12 md:mt-16">
          <ExperienceTimeline compact />
        </div>
        <Link href="/experience" className="t-meta link-u mt-8 inline-block">
          Full timeline
        </Link>
      </section>

      <ContactSection />
    </>
  );
}
