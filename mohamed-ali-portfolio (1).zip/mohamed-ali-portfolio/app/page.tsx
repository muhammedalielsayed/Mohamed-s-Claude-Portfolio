import Link from 'next/link';
import Hero from '@/components/Hero';
import AboutIntro from '@/components/AboutIntro';
import ProcessSection from '@/components/ProcessSection';
import WorkAcross from '@/components/WorkAcross';
import WorkGrid from '@/components/WorkGrid';
import NumbersSection from '@/components/NumbersSection';
import ExperienceTimeline from '@/components/ExperienceTimeline';
import FutureSection from '@/components/FutureSection';
import ContactSection from '@/components/ContactSection';
import SectionHeader from '@/components/SectionHeader';
import { projects } from '@/data/projects';

export default function HomePage() {
  return (
    <>
      <Hero />
      <AboutIntro />
      <ProcessSection />
      <WorkAcross />

      <section aria-labelledby="work-title" className="page py-20 md:py-32">
        <SectionHeader
          label="Selected work"
          id="work-title"
          title="Problems I've worked on"
          intro={<p className="text-muted">Eight case studies. Some with numbers, some without. Where there are no numbers, the thinking is the point.</p>}
        />
        <div className="mt-16 md:mt-24">
          <WorkGrid projects={projects} />
        </div>
      </section>

      <div className="border-t border-line bg-white/40">
        <NumbersSection />
      </div>

      <section aria-labelledby="exp-title" className="page py-20 md:py-32">
        <SectionHeader
          label="Experience"
          id="exp-title"
          title="Not a straight line"
          intro={<p className="text-muted">Printing shop to account management, with support, content, agencies and a failed clothing brand in between.</p>}
        />
        <div className="mt-14 md:mt-20">
          <ExperienceTimeline compact />
        </div>
        <Link href="/experience" className="t-meta link-u mt-8 inline-block">
          Full timeline
        </Link>
      </section>

      <div className="border-t border-line">
        <FutureSection />
      </div>
      <ContactSection />
    </>
  );
}
