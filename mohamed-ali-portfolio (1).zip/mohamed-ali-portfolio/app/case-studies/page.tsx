import type { Metadata } from 'next';
import Link from 'next/link';
import PageHeader from '@/components/PageHeader';
import SmartImage from '@/components/SmartImage';
import { projects } from '@/data/projects';

export const metadata: Metadata = {
  title: 'Case studies',
  description: 'An index of case studies by Mohamed Ali.',
};

const numbers: Record<string, string> = {
  documented: 'Documented data',
  approximate: 'Approximate',
  target: 'Targets',
  mixed: 'Results + objective',
  none: '—',
};

export default function CaseStudiesIndex() {
  return (
    <>
      <PageHeader
        label="Case studies / Index"
        title="Index"
        intro={<p>Every case study in one list. Problem first.</p>}
        aside={
          <p>
            Prefer pictures?{' '}
            <Link href="/work" className="link-u text-ink">
              View the work grid
            </Link>
          </p>
        }
      />
      <section className="page pb-24 md:pb-36" aria-label="Case study index">
        <div className="t-meta hidden grid-cols-12 gap-6 border-b border-ink pb-3 text-muted lg:grid">
          <span className="col-span-1">No.</span>
          <span className="col-span-4">Project</span>
          <span className="col-span-4">The problem</span>
          <span className="col-span-2">Industry</span>
          <span className="col-span-1 text-right">Numbers</span>
        </div>
        <ol>
          {projects.map((p) => (
            <li key={p.slug} className="border-b border-line" style={{ ['--project' as string]: p.accent }}>
              <Link
                href={`/case-studies/${p.slug}`}
                className="group grid grid-cols-4 items-center gap-x-4 gap-y-3 py-6 transition-colors hover:bg-white/70 lg:grid-cols-12 lg:gap-x-6 lg:py-7"
              >
                <span className="text-[1.05rem] font-bold tabular-nums transition-all duration-300 group-hover:translate-x-2 group-hover:text-accent-ink lg:col-span-1">
                  {p.number}
                </span>
                <span className="col-span-3 flex items-center gap-4 lg:col-span-4">
                  <span className="relative hidden aspect-square w-14 shrink-0 overflow-hidden md:block">
                    <SmartImage src={p.heroImage} alt="" tone={p.accent} sizes="56px" hint=" " />
                  </span>
                  <span className="text-[clamp(1.5rem,2.8vw,2.4rem)] font-extrabold uppercase leading-none tracking-[-0.04em]">
                    {p.title}
                  </span>
                </span>
                <span className="col-span-4 text-[15px] leading-snug text-muted lg:col-span-4 lg:text-base">{p.problemLine}</span>
                <span className="t-meta col-span-2 text-muted lg:col-span-2">{p.industry}</span>
                <span className="t-meta col-span-2 text-right text-muted lg:col-span-1">{numbers[p.resultType]}</span>
              </Link>
            </li>
          ))}
        </ol>
      </section>
    </>
  );
}
