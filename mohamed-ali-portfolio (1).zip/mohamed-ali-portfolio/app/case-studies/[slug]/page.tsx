import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import CaseStudyHero from '@/components/CaseStudyHero';
import CaseStudySection from '@/components/CaseStudySection';
import Gallery, { autoGallery } from '@/components/Gallery';
import Metric from '@/components/Metric';
import NextCaseStudy from '@/components/NextCaseStudy';
import { Reveal } from '@/components/Reveal';
import { getNextProject, getProject, projects } from '@/data/projects';
import type { Block } from '@/lib/types';

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const p = getProject(params.slug);
  if (!p) return {};
  return { title: p.title, description: `${p.subtitle} ${p.summary}` };
}

const defaultLabels = {
  context: 'Context',
  problem: 'Problem',
  myRole: 'My role',
  thinking: 'Thinking',
  solution: 'Solution',
  execution: 'Execution',
} as const;

export default function CaseStudyPage({ params }: { params: { slug: string } }) {
  const project = getProject(params.slug);
  if (!project) notFound();
  const next = getNextProject(project.slug);

  const blocks = (Object.keys(defaultLabels) as (keyof typeof defaultLabels)[])
    .map((k) => ({ key: k, block: project[k] as Block | undefined }))
    .filter((b): b is { key: keyof typeof defaultLabels; block: Block } => Boolean(b.block));

  let n = 0;
  const num = () => String(++n).padStart(2, '0');
  const gallery = project.gallery?.length ? project.gallery : autoGallery(project.images);

  return (
    <article
      style={{ ['--project' as string]: project.accent, ['--project-text' as string]: project.accentText }}
      aria-labelledby="case-title"
    >
      <span id="case-title" className="sr-only">
        {project.title} case study
      </span>
      <CaseStudyHero project={project} total={projects.length} />

      <div className="page py-16 md:py-28">
        <Reveal className="grid-page">
          <p className="t-h3 col-span-4 md:col-span-9 md:col-start-4">{project.summary}</p>
        </Reveal>
      </div>

      {blocks.map(({ key, block }) => (
        <CaseStudySection key={key} number={num()} label={block.label ?? defaultLabels[key]} block={block} />
      ))}

      {gallery.length > 0 && (
        <section aria-label="Visual work" className="page border-t border-line py-14 md:py-24">
          <p className="t-meta mb-8 text-muted">Visual work</p>
          <Gallery blocks={gallery} title={project.title} tone={project.accent} />
        </section>
      )}

      {project.results && project.results.length > 0 && (
        <CaseStudySection number={num()} label={project.resultsLabel ?? 'Results'}>
          <div className={`grid gap-x-6 gap-y-10 ${project.results.length > 3 ? 'grid-cols-2' : 'grid-cols-1 sm:grid-cols-2'}`}>
            {project.results.map((m) => (
              <Reveal key={m.label} y={14}>
                <Metric metric={m} size="md" />
              </Reveal>
            ))}
          </div>
          {project.resultsNote && <p className="mt-10 max-w-[60ch] text-[15px] text-muted">{project.resultsNote}</p>}
        </CaseStudySection>
      )}

      <CaseStudySection number={num()} label={project.takeaway.label ?? 'Takeaway'} block={project.takeaway} />

      {project.closing && (
        <section aria-label="Closing thought" className="page border-t border-line py-20 md:py-36">
          <Reveal className="grid-page">
            <p className="col-span-4 text-[clamp(2rem,5vw,4.6rem)] font-extrabold leading-[0.98] tracking-[-0.045em] md:col-span-10 md:col-start-2">
              {project.closing}
            </p>
          </Reveal>
        </section>
      )}

      <NextCaseStudy project={next} />
    </article>
  );
}
