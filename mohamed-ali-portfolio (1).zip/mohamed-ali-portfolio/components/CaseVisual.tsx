import type { Visual } from '@/lib/types';

const isArabic = (s: string) => /[\u0600-\u06FF]/.test(s);

/** Diagram-like visuals rendered from data. No images required. */
export default function CaseVisual({ visual }: { visual: Visual }) {
  switch (visual.kind) {
    case 'statement':
      return (
        <figure className="border-l-4 py-2 pl-6 md:pl-10" style={{ borderColor: 'var(--project)' }}>
          <blockquote className="text-[clamp(1.7rem,3.6vw,3.2rem)] font-bold leading-[1.05] tracking-[-0.035em]">
            {visual.text}
          </blockquote>
          {visual.attribution && <figcaption className="t-meta mt-5 text-muted">{visual.attribution}</figcaption>}
        </figure>
      );

    case 'flow':
      return (
        <figure>
          <ol className="flex flex-col md:flex-row md:items-stretch">
            {visual.steps.map((s, i) => (
              <li key={s} className="flex flex-col md:flex-1 md:flex-row md:items-center">
                <div className="flex flex-1 flex-col justify-between gap-6 border border-ink bg-white p-4 md:min-h-[140px]">
                  <span className="t-meta" style={{ color: 'var(--project-text)' }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span className="text-[1.05rem] font-bold leading-tight">{s}</span>
                </div>
                {i < visual.steps.length - 1 && (
                  <span aria-hidden className="flex h-8 items-center justify-center md:h-auto md:w-8">
                    <span className="block h-full w-px bg-ink md:h-px md:w-full" />
                  </span>
                )}
              </li>
            ))}
          </ol>
          {visual.caption && <figcaption className="t-meta mt-4 text-muted">{visual.caption}</figcaption>}
        </figure>
      );

    case 'framework':
      return (
        <figure>
          <ol className="grid grid-cols-2 border-t border-ink md:grid-cols-4">
            {visual.steps.map((s, i) => {
              const last = i === visual.steps.length - 1;
              return (
                <li
                  key={s}
                  className="border-b border-line py-5 pr-4 md:border-b-0 md:border-r md:px-5 md:first:pl-0 md:last:border-r-0"
                >
                  <span className="t-meta text-muted">Step {i + 1}</span>
                  <span
                    className="mt-2 block text-[clamp(1.5rem,2.6vw,2.4rem)] font-extrabold uppercase leading-none tracking-[-0.04em]"
                    style={last ? { color: 'var(--project-text)' } : undefined}
                  >
                    {s}
                  </span>
                </li>
              );
            })}
          </ol>
          {visual.caption && <figcaption className="t-meta mt-4 text-muted">{visual.caption}</figcaption>}
        </figure>
      );

    case 'compare':
      return (
        <figure>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-stretch">
            <div className="border border-line p-5 md:p-7">
              <p className="text-[1.5rem] font-extrabold uppercase tracking-[-0.03em] text-muted">{visual.left.title}</p>
              <ul className="mt-5 space-y-2 text-muted">
                {visual.left.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
            <span className="t-meta flex items-center justify-center text-muted">vs</span>
            <div className="border-2 bg-white p-5 md:p-7" style={{ borderColor: 'var(--project)' }}>
              <p className="text-[1.5rem] font-extrabold uppercase tracking-[-0.03em]">{visual.right.title}</p>
              <ul className="mt-5 space-y-2">
                {visual.right.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
          </div>
          {visual.caption && <figcaption className="t-meta mt-4 text-muted">{visual.caption}</figcaption>}
        </figure>
      );

    case 'themes':
      return (
        <figure>
          {visual.caption && <figcaption className="t-meta mb-4 text-muted">{visual.caption}</figcaption>}
          <ul className="flex flex-wrap gap-2">
            {visual.items.map((t) => {
              const ar = isArabic(t);
              return (
                <li
                  key={t}
                  lang={ar ? 'ar' : undefined}
                  dir={ar ? 'rtl' : undefined}
                  className={`border px-3 py-2 text-[15px] font-medium md:text-base ${ar ? 'border-transparent text-white' : 'border-line bg-white'}`}
                  style={ar ? { background: 'var(--project-text)' } : undefined}
                >
                  {t}
                </li>
              );
            })}
          </ul>
        </figure>
      );

    case 'structure':
      return (
        <figure>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            {visual.columns.map((c) => (
              <div key={c.title} className="border border-ink bg-white p-5">
                <p className="text-[1.15rem] font-extrabold uppercase tracking-[-0.02em]">{c.title}</p>
                <ul className="mt-4 space-y-1.5 text-[15px]">
                  {c.items.map((it) => (
                    <li key={it} className={it === 'KPIs' ? 'font-semibold' : ''} style={it === 'KPIs' ? { color: 'var(--project-text)' } : undefined}>
                      {it}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          {visual.caption && <figcaption className="t-meta mt-4 text-muted">{visual.caption}</figcaption>}
        </figure>
      );

    case 'scatter': {
      const positions = [
        'left-[4%] top-[8%] -rotate-3',
        'left-[46%] top-[2%] rotate-2',
        'left-[18%] top-[40%] rotate-1',
        'left-[56%] top-[46%] -rotate-2',
        'left-[8%] top-[74%] rotate-3',
      ];
      return (
        <figure>
          <div className="grid grid-cols-1 items-center gap-6 md:grid-cols-[1fr_auto_1fr]">
            <div className="relative hidden h-[260px] border border-dashed border-muted md:block" aria-hidden>
              {visual.sources.map((s, i) => (
                <span key={s} className={`absolute border border-line bg-white px-3 py-2 text-[15px] font-medium ${positions[i % positions.length]}`}>
                  {s}
                </span>
              ))}
            </div>
            <ul className="flex flex-wrap gap-2 border border-dashed border-muted p-4 md:hidden">
              {visual.sources.map((s) => (
                <li key={s} className="border border-line bg-white px-3 py-2 text-[15px]">
                  {s}
                </li>
              ))}
            </ul>
            <span aria-hidden className="text-center text-[2rem] leading-none text-muted">
              <span className="hidden md:inline">→</span>
              <span className="md:hidden">↓</span>
            </span>
            <div className="border-2 bg-white p-5" style={{ borderColor: 'var(--project)' }}>
              <p className="text-[1.15rem] font-extrabold uppercase tracking-[-0.02em]">{visual.outcome}</p>
              <ol className="mt-4 space-y-2 text-[15px]">
                {['Entry point', 'Shared record', 'Clear owner', 'Next step'].map((r, i) => (
                  <li key={r} className="flex gap-3 border-t border-line pt-2">
                    <span className="text-muted">{i + 1}</span>
                    {r}
                  </li>
                ))}
              </ol>
            </div>
          </div>
          <figcaption className="sr-only">
            Information scattered across {visual.sources.join(', ')} becomes {visual.outcome.toLowerCase()}.
          </figcaption>
        </figure>
      );
    }
  }
}
