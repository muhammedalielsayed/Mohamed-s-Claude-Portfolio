'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { site } from '@/data/site';

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const firstLinkRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) firstLinkRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && open) {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open]);

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/') || (href === '/work' && pathname.startsWith('/case-studies'));

  return (
    <header
      className={`sticky top-0 z-50 bg-paper transition-[border-color] duration-300 ${
        scrolled || open ? 'border-b border-line' : 'border-b border-transparent'
      }`}
    >
      <nav aria-label="Main" className="page flex h-[var(--nav-h)] items-center justify-between gap-6">
        <Link href="/" className="text-[15px] font-extrabold uppercase tracking-[-0.01em] md:text-base" aria-label="Mohamed Ali, home">
          Mohamed Ali
        </Link>

        <ul className="hidden items-center gap-9 md:flex">
          {site.nav.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={isActive(item.href) ? 'page' : undefined}
                className="t-meta group relative flex items-center gap-2 py-2 hover:text-accent-ink"
              >
                <span
                  aria-hidden
                  className={`square transition-transform duration-300 ${isActive(item.href) ? 'scale-100' : 'scale-0 group-hover:scale-100'}`}
                />
                {item.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <Link href="/contact" className="btn btn-solid hidden !min-h-[40px] !px-5 md:inline-flex">
            Let&apos;s talk
          </Link>
          <button
            ref={toggleRef}
            type="button"
            className="relative -mr-2 flex h-11 w-11 items-center justify-center md:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen((v) => !v)}
          >
            <span className="relative block h-3 w-6">
              <span className={`absolute left-0 block h-[2px] w-6 bg-ink transition-transform duration-300 ${open ? 'top-[5px] rotate-45' : 'top-0'}`} />
              <span className={`absolute left-0 block h-[2px] w-6 bg-ink transition-transform duration-300 ${open ? 'top-[5px] -rotate-45' : 'top-[10px]'}`} />
            </span>
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            className="fixed inset-x-0 bottom-0 top-[var(--nav-h)] z-40 overflow-y-auto bg-paper md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <div className="page flex min-h-full flex-col justify-between pb-10 pt-8">
              <ul className="flex flex-col">
                {[{ label: 'Home', href: '/' }, ...site.nav, ...site.secondaryNav].map((item, i) => (
                  <motion.li
                    key={item.href}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.04 * i, duration: 0.4 }}
                    className="border-b border-line"
                  >
                    <Link
                      ref={i === 0 ? firstLinkRef : undefined}
                      href={item.href}
                      aria-current={pathname === item.href ? 'page' : undefined}
                      className="flex items-baseline justify-between py-4 text-[2.4rem] font-extrabold uppercase leading-none tracking-[-0.04em]"
                    >
                      {item.label}
                      <span className="t-meta text-muted">{String(i + 1).padStart(2, '0')}</span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
              <div className="mt-10 flex flex-col gap-3">
                <Link href="/contact" className="btn btn-solid w-full">
                  Let&apos;s talk
                </Link>
                <p className="t-meta text-muted">
                  {site.location} / {site.disciplines.join(' / ')}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
