'use client';
import Link from 'next/link';
import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import SmartImage from './SmartImage';
import type { Project } from '@/lib/types';

const ease = [0.22, 1, 0.36, 1] as const;
const resultTypeLabel: Record<Project['resultType'], string> = {
  documented: 'Documented data',
  approximate: 'Approximate performance',
  target: 'Targets only',
  mixed: 'Results + objectives',
  none: 'No numbers — problem & thinking',
};

export default function CaseStudyHero({ project, total }: { project: Project; total: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? ['0%', '0%'] : ['-6%', '6%']);
  const words = project.title.split(' ');

  const meta = [
    { k: 'Industry', v: project.industry },
    { k: 'Role', v: project.role },
    { k: 'Type', v: project.category },
    { k: 'Numbers', v: resultTypeLabel[project.resultType] },
  ];

  return (
    <header className="page pt-8 md:pt-12">
      <nav aria-label="Breadcrumb" className="t-meta flex items-center justify-between border-b border-line pb-4 text-muted">
        <Link href="/case-studies" className="link-u">
          Case studies
        </Link>
        <span>
          <span style={{ color: 'var(--project-text)' }}>{project.number}</span> / {String(total).padStart(2, '0')}
        </span>
      </nav>

      <h1 className="t-hero mt-10 md:mt-14" aria-label={project.title}>
        {words.map((w, i) => (
          <span key={i} className="mr-[0.2em] inline-block overflow-hidden pb-[0.04em] align-top last:mr-0">
            <motion.span
              className="inline-block"
              initial={reduce ? false : { y: '105%' }}
              animate={{ y: '0%' }}
              transition={{ duration: 1, delay: 0.1 + i * 0.1, ease }}
            >
              {w}
            </motion.span>
          </span>
        ))}
      </h1>

      <div className="grid-page mt-8 gap-y-10 md:mt-12">
        <p className="t-h3 col-span-4 md:col-span-7">{project.subtitle}</p>
        <dl className="col-span-4 grid grid-cols-2 gap-x-4 gap-y-5 self-end md:col-span-4 md:col-start-9">
          {meta.map((m) => (
            <div key={m.k} className="border-t border-line pt-2">
              <dt className="t-meta text-muted">{m.k}</dt>
              <dd className="mt-1 text-[15px] font-medium leading-snug">{m.v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div ref={ref} className="relative mt-12 aspect-[4/5] overflow-hidden sm:aspect-[16/10] md:mt-16 lg:aspect-[16/8]">
        <span aria-hidden className="absolute left-0 top-0 z-10 h-1.5 w-24 md:w-40" style={{ background: 'var(--project)' }} />
        <motion.div className="absolute inset-[-8%_0]" style={{ y }}>
          <SmartImage
            src={project.heroImage}
            alt={`${project.title} — hero visual`}
            tone={project.accent}
            priority
            sizes="100vw"
            hint={`Hero image — /images/projects/${project.slug}/hero.jpg`}
          />
        </motion.div>
      </div>

      <ul className="mt-5 flex flex-wrap gap-2" aria-label="Tags">
        {project.tags.map((t) => (
          <li key={t} className="chip">
            {t}
          </li>
        ))}
      </ul>
    </header>
  );
}
