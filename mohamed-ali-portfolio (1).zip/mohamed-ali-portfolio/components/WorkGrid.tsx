import ProjectCard from './ProjectCard';
import { Reveal } from './Reveal';
import type { Project } from '@/lib/types';

/**
 * Asymmetric editorial grid. Positions repeat every 8 projects,
 * so adding a project never needs layout changes.
 */
const slots = [
  { cls: 'lg:col-span-7', aspect: 'aspect-[4/3]' },
  { cls: 'lg:col-span-4 lg:col-start-9 lg:mt-48', aspect: 'aspect-[4/5]' },
  { cls: 'lg:col-span-5 lg:col-start-2', aspect: 'aspect-[4/5]' },
  { cls: 'lg:col-span-6 lg:col-start-7 lg:mt-32', aspect: 'aspect-[4/3]' },
  { cls: 'lg:col-span-7', aspect: 'aspect-[16/10]' },
  { cls: 'lg:col-span-4 lg:col-start-9 lg:mt-40', aspect: 'aspect-[4/5]' },
  { cls: 'lg:col-span-6', aspect: 'aspect-[4/3]' },
  { cls: 'lg:col-span-5 lg:col-start-8 lg:mt-28', aspect: 'aspect-[4/3]' },
];

export default function WorkGrid({ projects }: { projects: Project[] }) {
  return (
    <div className="grid-page gap-y-16 md:gap-y-20 lg:gap-y-28">
      {projects.map((p, i) => {
        const slot = slots[i % slots.length];
        return (
          <Reveal key={p.slug} className={`col-span-4 md:col-span-6 ${slot.cls}`}>
            <ProjectCard project={p} aspect={slot.aspect} priority={i < 2} />
          </Reveal>
        );
      })}
    </div>
  );
}
