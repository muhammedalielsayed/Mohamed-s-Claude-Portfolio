import Link from 'next/link';
import SmartImage from './SmartImage';
import type { Project } from '@/lib/types';

export default function ProjectCard({
  project,
  aspect = 'aspect-[4/3]',
  priority,
}: {
  project: Project;
  aspect?: string;
  priority?: boolean;
}) {
  return (
    <article className="group relative">
      <Link
        href={`/case-studies/${project.slug}`}
        className="block focus-visible:outline-offset-8"
        aria-label={`${project.title} — view case study`}
      >
        <div className="mb-4 flex items-center justify-between border-t border-ink pt-3">
          <span className="text-[1.05rem] font-bold tabular-nums transition-all duration-500 ease-editorial group-hover:translate-x-3 group-hover:text-accent-ink">
            {project.number}
          </span>
          <span className="t-meta text-muted">{project.industry}</span>
        </div>

        <div className={`relative overflow-hidden ${aspect}`}>
          <div className="absolute inset-0 transition-transform duration-[900ms] ease-editorial group-hover:scale-[1.035]">
            <SmartImage
              src={project.heroImage}
              alt={`${project.title} project visual`}
              tone={project.accent}
              sizes="(min-width: 1024px) 50vw, 100vw"
              priority={priority}
              hint={`${project.title} — hero.jpg`}
            />
          </div>
          <span
            aria-hidden
            className="absolute bottom-0 left-0 h-1 w-full origin-left scale-x-0 bg-accent transition-transform duration-500 ease-editorial group-hover:scale-x-100"
          />
        </div>

        <div className="mt-5 flex flex-col gap-1 md:flex-row md:items-baseline md:justify-between md:gap-6">
          <h3 className="text-[clamp(1.9rem,3.4vw,3rem)] font-extrabold uppercase leading-[0.95] tracking-[-0.04em]">
            {project.title}
          </h3>
          <span className="t-meta text-muted md:text-right">{project.role}</span>
        </div>

        <p className="mt-4 max-w-[48ch] text-[0.95em] leading-snug">
          <span className="text-muted">The problem: </span>
          {project.problemLine}
        </p>
        <p className="mt-2 max-w-[48ch] text-[0.95em] leading-snug text-muted">{project.summary}</p>

        <span className="t-meta mt-5 inline-flex items-center gap-2">
          <span className="border-b border-current pb-0.5 transition-colors group-hover:text-accent-ink">View case study</span>
          <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1">
            →
          </span>
        </span>
      </Link>
    </article>
  );
}
