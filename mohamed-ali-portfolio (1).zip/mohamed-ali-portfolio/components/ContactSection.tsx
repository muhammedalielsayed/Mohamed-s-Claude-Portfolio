import { contactHref, site } from '@/data/site';

const links = [
  { kind: 'email' as const, label: 'Email me' },
  { kind: 'linkedin' as const, label: 'LinkedIn' },
  { kind: 'instagram' as const, label: 'Instagram' },
];

/** Inverted closing block. The one dark moment on the page. */
export default function ContactSection({
  title = "Let's build something.",
  lines = ['Projects.', 'Interesting problems.', 'Collaborations.', 'Good conversations.'],
}: {
  title?: string;
  lines?: string[];
}) {
  return (
    <section id="contact" aria-labelledby="contact-title" className="bg-ink text-paper">
      <div className="page grid-page gap-y-12 py-24 md:py-36">
        <p className="t-meta col-span-4 flex items-center gap-2 text-paper/60 md:col-span-3 md:pt-3">
          <span className="square" aria-hidden />
          Contact
        </p>
        <div className="col-span-4 md:col-span-9">
          <h2 id="contact-title" className="t-h2">
            {title}
          </h2>
          <p className="t-lead mt-10 text-paper/70">
            {lines.map((l) => (
              <span key={l} className="block">
                {l}
              </span>
            ))}
          </p>
          <ul className="mt-12 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            {links.map((l, i) => {
              const href = contactHref(l.kind);
              const external = l.kind !== 'email';
              return (
                <li key={l.kind} className="flex flex-col gap-2">
                  <a
                    href={href ?? '#contact'}
                    className={`btn ${i === 0 ? 'btn-inverse' : 'btn-inverse-line'} w-full sm:w-auto`}
                    {...(href && external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                    aria-describedby={`contact-${l.kind}`}
                  >
                    {l.label}
                  </a>
                  <span id={`contact-${l.kind}`} className="text-[12px] text-paper/50">
                    {site.contact[l.kind]}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
