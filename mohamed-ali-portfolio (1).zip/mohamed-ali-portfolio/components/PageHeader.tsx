import { Reveal } from './Reveal';

/** Header for inner pages. Big title, one short intro, optional side note. */
export default function PageHeader({
  label,
  title,
  intro,
  aside,
}: {
  label: string;
  title: string;
  intro?: React.ReactNode;
  aside?: React.ReactNode;
}) {
  return (
    <header className="page pb-14 pt-10 md:pb-24 md:pt-16">
      <p className="t-meta flex items-center gap-2 border-b border-line pb-4 text-muted">
        <span className="square" aria-hidden />
        {label}
      </p>
      <h1 className="t-hero mt-10 md:mt-14">{title}</h1>
      {(intro || aside) && (
        <Reveal className="grid-page mt-10 gap-y-8 md:mt-14">
          {intro && <div className="t-lead col-span-4 md:col-span-7">{intro}</div>}
          {aside && <div className="col-span-4 text-muted md:col-span-4 md:col-start-9">{aside}</div>}
        </Reveal>
      )}
    </header>
  );
}
