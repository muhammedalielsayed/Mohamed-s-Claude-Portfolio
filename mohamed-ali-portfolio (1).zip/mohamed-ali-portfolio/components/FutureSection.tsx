import { Reveal } from './Reveal';

const directions = [
  {
    title: 'Business',
    line: 'I want to get genuinely good at understanding and building businesses. Why some ideas become businesses and others don’t.',
  },
  {
    title: 'Software',
    line: 'I want to learn more about software, technology and products. I like understanding how things work underneath the surface.',
  },
  {
    title: 'Entrepreneurship',
    line: 'Eventually, build and invest in more than one business. And help younger people start their own projects with what I’ve learned by then.',
  },
];

/** "I'm still figuring it out" + what's next. */
export default function FutureSection() {
  return (
    <section aria-labelledby="future-title" className="page py-20 md:py-32">
      <div className="grid-page gap-y-10">
        <p className="t-meta col-span-4 flex items-center gap-2 text-muted md:col-span-3 md:pt-3">
          <span className="square" aria-hidden />
          What&apos;s next
        </p>
        <div className="col-span-4 md:col-span-9">
          <h2 id="future-title" className="t-h2">
            I&apos;m still figuring it out.
          </h2>
        </div>

        <Reveal className="col-span-4 md:col-span-5 md:col-start-4">
          <p className="t-lead">I know I want to build.</p>
          <p className="t-lead mt-4 text-muted">
            Businesses.
            <br />
            Products.
            <br />
            Systems.
            <br />
            Things that actually work.
          </p>
        </Reveal>
        <Reveal delay={0.1} className="col-span-4 space-y-5 md:col-span-4 md:col-start-9">
          <p>I&apos;m interested in software because I like understanding how things work underneath the surface.</p>
          <p>I&apos;m interested in business because I want to understand why some ideas become businesses and others don&apos;t.</p>
          <p>
            And I&apos;m interested in personal branding because I want to document the process rather than pretend I&apos;ve already
            figured everything out.
          </p>
        </Reveal>
      </div>

      <ol className="mt-16 grid gap-x-6 border-t border-ink md:mt-24 md:grid-cols-3">
        {directions.map((d, i) => (
          <li key={d.title} className="border-b border-line py-8 md:border-b-0 md:border-r md:px-6 md:first:pl-0 md:last:border-r-0">
            <Reveal delay={i * 0.08} y={14}>
              <p className="t-meta text-muted">Direction {String(i + 1).padStart(2, '0')}</p>
              <h3 className="mt-3 text-[1.8rem] font-extrabold uppercase tracking-[-0.03em]">{d.title}</h3>
              <p className="mt-3 text-muted">{d.line}</p>
            </Reveal>
          </li>
        ))}
      </ol>
    </section>
  );
}
