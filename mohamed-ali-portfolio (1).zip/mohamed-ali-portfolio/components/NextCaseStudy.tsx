import Link from 'next/link';
import type { Project } from '@/lib/types';

export default function NextCaseStudy({ project }: { project: Project }) {
  return (
    <Link href={`/case-studies/${project.slug}`} className="group block border-t border-ink bg-white/40">
      <div className="page py-16 md:py-24">
        <div className="t-meta flex items-center justify-between text-muted">
          <span className="flex items-center gap-2 text-ink">
            Next case study
            <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1">
              →
            </span>
          </span>
          <span>
            {project.number} / {project.industry}
          </span>
        </div>
        <p className="t-h2 mt-8 transition-transform duration-500 ease-editorial group-hover:translate-x-3 md:mt-12">
          {project.title}
        </p>
        <p className="t-lead mt-5 max-w-[40ch] text-muted">{project.subtitle}</p>
        <span aria-hidden className="mt-10 block h-1 w-full origin-left scale-x-0 bg-accent transition-transform duration-700 ease-editorial group-hover:scale-x-100" />
      </div>
    </Link>
  );
}
