import Link from 'next/link';
import { experience } from '@/data/experience';
import { Reveal } from './Reveal';

export default function ExperienceTimeline({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <ol className="border-t border-ink">
        {experience.map((e) => (
          <li key={e.id} className="border-b border-line">
            <div className="grid-page items-baseline gap-y-2 py-5 md:py-6">
              <span className="t-meta col-span-1 text-muted md:col-span-1">{e.chapter}</span>
              <span className="col-span-3 flex items-center gap-3 text-[clamp(1.4rem,2.6vw,2.2rem)] font-extrabold uppercase leading-none tracking-[-0.03em] md:col-span-5">
                {e.title}
                {e.current && (
                  <span className="t-meta flex items-center gap-1.5 text-accent-ink">
                    <span className="square" aria-hidden />
                    Now
                  </span>
                )}
              </span>
              <span className="col-span-3 col-start-2 text-[15px] text-muted md:col-span-6 md:col-start-7 md:text-base">
                {e.roles.join(' / ')}
                {e.side && <span className="text-ink"> + {e.side.title}</span>}
              </span>
            </div>
          </li>
        ))}
      </ol>
    );
  }

  return (
    <ol className="relative">
      {experience.map((e) => (
        <li key={e.id} className="border-t border-line">
          <Reveal y={20}>
            <div className="grid-page gap-y-6 py-12 md:py-16">
              <div className="col-span-4 md:col-span-2">
                <span className="t-outline block text-[clamp(3rem,6vw,5.5rem)] font-extrabold leading-none tracking-[-0.05em] text-ink/80">
                  {e.chapter}
                </span>
              </div>
              <div className="col-span-4 md:col-span-4">
                <h3 className="text-[clamp(1.8rem,3.2vw,2.8rem)] font-extrabold uppercase leading-[0.95] tracking-[-0.04em]">
                  {e.title}
                </h3>
                {(e.subtitle || e.current) && (
                  <p className={`t-meta mt-3 flex items-center gap-2 ${e.current ? 'text-accent-ink' : 'text-muted'}`}>
                    {e.current && <span className="square" aria-hidden />}
                    {e.subtitle}
                  </p>
                )}
                <ul className="mt-5 flex flex-wrap gap-2">
                  {e.roles.map((r) => (
                    <li key={r} className="chip">
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="col-span-4 space-y-3 md:col-span-5 md:col-start-8">
                {e.story.map((s) => (
                  <p key={s} className="t-body">
                    {s}
                  </p>
                ))}
                {e.projectSlug && (
                  <Link href={`/case-studies/${e.projectSlug}`} className="t-meta link-u mt-3 inline-block">
                    Case study
                  </Link>
                )}
                {e.side && (
                  <div className="mt-8 border-l-2 border-dashed border-ink/40 pl-5">
                    <p className="t-meta text-muted">Alongside</p>
                    <p className="mt-2 text-[1.4rem] font-extrabold uppercase tracking-[-0.03em]">{e.side.title}</p>
                    <p className="t-meta mt-1 text-muted">{e.side.roles.join(' / ')}</p>
                    <p className="mt-3">{e.side.story}</p>
                    <Link href="/case-studies/rlvnt" className="t-meta link-u mt-3 inline-block">
                      Case study
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </Reveal>
        </li>
      ))}
    </ol>
  );
}
