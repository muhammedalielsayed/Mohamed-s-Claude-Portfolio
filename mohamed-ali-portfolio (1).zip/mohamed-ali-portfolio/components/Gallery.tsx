import SmartImage from './SmartImage';
import { ImageReveal } from './Reveal';
import type { GalleryBlock } from '@/lib/types';

/**
 * Data-driven gallery. Supported layouts:
 * full | two | three | screenshot | mobile | dashboard
 * Multi-image rows become swipeable on mobile.
 */
export default function Gallery({
  blocks,
  title,
  tone,
}: {
  blocks: GalleryBlock[];
  title: string;
  tone?: string;
}) {
  return (
    <div className="space-y-6 md:space-y-10">
      {blocks.map((b, bi) => (
        <figure key={bi}>
          <GalleryRow block={b} title={title} tone={tone} />
          {b.caption && (
            <figcaption className="t-meta mt-3 flex items-center justify-between text-muted">
              <span>{b.caption}</span>
              {['two', 'three', 'mobile'].includes(b.layout) && b.images.length > 1 && (
                <span className="md:hidden" aria-hidden>
                  Swipe
                </span>
              )}
            </figcaption>
          )}
        </figure>
      ))}
    </div>
  );
}

function GalleryRow({ block, title, tone }: { block: GalleryBlock; title: string; tone?: string }) {
  const alt = (i: number) => block.alts?.[i] ?? `${title} — ${block.caption ?? 'project image'} ${block.images.length > 1 ? i + 1 : ''}`.trim();

  switch (block.layout) {
    case 'full':
      return (
        <ImageReveal className="relative aspect-[4/5] sm:aspect-[16/9]">
          <SmartImage src={block.images[0]} alt={alt(0)} tone={tone} sizes="100vw" hint="Full-width image" />
        </ImageReveal>
      );

    case 'dashboard':
      return (
        <ImageReveal className="border border-ink bg-white p-2 md:p-3">
          <div className="t-meta flex items-center justify-between border-b border-line px-1 pb-2 text-muted">
            <span>Dashboard</span>
            <span aria-hidden className="flex gap-1">
              <span className="h-2 w-2 bg-line" />
              <span className="h-2 w-2 bg-line" />
              <span className="h-2 w-2 bg-line" />
            </span>
          </div>
          <div className="relative mt-2 aspect-[4/3] sm:aspect-[21/9]">
            <SmartImage src={block.images[0]} alt={alt(0)} tone={tone} sizes="100vw" fit="cover" hint="Dashboard screenshot" />
          </div>
        </ImageReveal>
      );

    case 'screenshot':
      return (
        <div className="grid-page">
          <ImageReveal className="col-span-4 border border-line bg-white p-2 md:col-span-10 md:col-start-2 md:p-3">
            <div className="relative aspect-[4/3] sm:aspect-[16/10]">
              <SmartImage src={block.images[0]} alt={alt(0)} tone={tone} sizes="(min-width: 768px) 80vw, 100vw" hint="Screenshot" />
            </div>
          </ImageReveal>
        </div>
      );

    case 'mobile':
      return (
        <div className="swipe md:mx-0 md:grid md:grid-cols-3 md:gap-6 md:overflow-visible md:px-[8%] md:pb-0">
          {block.images.map((src, i) => (
            <ImageReveal key={src} delay={i * 0.08} className="w-[62%] shrink-0 snap-center md:w-auto">
              <div className="border border-ink bg-white p-1.5">
                <div className="relative aspect-[9/19]">
                  <SmartImage src={src} alt={alt(i)} tone={tone} sizes="(min-width: 768px) 28vw, 62vw" hint="Mobile screenshot" />
                </div>
              </div>
            </ImageReveal>
          ))}
        </div>
      );

    case 'two':
    case 'three': {
      const cols = block.layout === 'two' ? 'md:grid-cols-2' : 'md:grid-cols-3';
      const aspect = block.layout === 'two' ? 'aspect-[4/5]' : 'aspect-[3/4]';
      return (
        <div className={`swipe md:mx-0 md:grid ${cols} md:gap-6 md:overflow-visible md:px-0 md:pb-0`}>
          {block.images.map((src, i) => (
            <ImageReveal key={src} delay={i * 0.08} className={`relative w-[82%] shrink-0 snap-center md:w-auto ${aspect}`}>
              <SmartImage src={src} alt={alt(i)} tone={tone} sizes={block.layout === 'two' ? '(min-width: 768px) 50vw, 82vw' : '(min-width: 768px) 33vw, 82vw'} />
            </ImageReveal>
          ))}
        </div>
      );
    }
  }
}

/** Builds a simple gallery from a flat image list (first full, rest in pairs). */
export function autoGallery(images: string[]): GalleryBlock[] {
  if (!images.length) return [];
  const [first, ...rest] = images;
  const blocks: GalleryBlock[] = [{ layout: 'full', images: [first] }];
  for (let i = 0; i < rest.length; i += 2) {
    const chunk = rest.slice(i, i + 2);
    blocks.push(chunk.length === 2 ? { layout: 'two', images: chunk } : { layout: 'full', images: chunk });
  }
  return blocks;
}
