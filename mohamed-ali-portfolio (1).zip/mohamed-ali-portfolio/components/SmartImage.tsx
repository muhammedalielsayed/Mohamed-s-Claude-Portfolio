'use client';
import Image from 'next/image';
import { useState } from 'react';

type Props = {
  src?: string;
  alt: string;
  /** Tone used for the placeholder hatch (e.g. a project accent). */
  tone?: string;
  sizes?: string;
  priority?: boolean;
  fit?: 'cover' | 'contain';
  className?: string;
  imgClassName?: string;
  /** Short label shown on the placeholder, e.g. "Hero image". */
  hint?: string;
};

/**
 * Next.js Image with a graceful placeholder.
 * If the file doesn't exist yet, a hatched frame shows the expected path,
 * so the layout never breaks while you are still collecting images.
 * The parent sets the size (aspect ratio or height).
 */
export default function SmartImage({
  src,
  alt,
  tone,
  sizes = '100vw',
  priority,
  fit = 'cover',
  className = '',
  imgClassName = '',
  hint,
}: Props) {
  const [state, setState] = useState<'loading' | 'loaded' | 'error'>(src ? 'loading' : 'error');
  const showPlaceholder = state !== 'loaded';

  return (
    <div className={`relative h-full w-full overflow-hidden ${className}`}>
      {showPlaceholder && (
        <div
          role={state === 'error' ? 'img' : undefined}
          aria-label={state === 'error' ? alt : undefined}
          className="ph-hatch absolute inset-0 flex flex-col justify-between p-3 text-muted md:p-4"
          style={{ ['--tone' as string]: tone ?? '#b9b4a8' }}
        >
          <span aria-hidden className="flex justify-between">
            <Corner />
            <Corner flip />
          </span>
          {state === 'error' && (
            <span aria-hidden className="flex flex-col gap-1">
              <span className="t-meta text-ink/70">{hint ?? 'Image'}</span>
              {src && <span className="break-all text-[11px] leading-snug text-muted">{src}</span>}
            </span>
          )}
        </div>
      )}
      {src && state !== 'error' && (
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          priority={priority}
          onLoad={() => setState('loaded')}
          onError={() => setState('error')}
          className={`${fit === 'contain' ? 'object-contain' : 'object-cover'} transition-opacity duration-700 ${
            state === 'loaded' ? 'opacity-100' : 'opacity-0'
          } ${imgClassName}`}
        />
      )}
    </div>
  );
}

function Corner({ flip }: { flip?: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" className={flip ? 'rotate-90' : ''} fill="none">
      <path d="M1 13V1h12" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}
