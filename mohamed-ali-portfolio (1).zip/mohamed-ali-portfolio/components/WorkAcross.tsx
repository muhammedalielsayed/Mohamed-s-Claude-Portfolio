'use client';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { areas } from '@/data/skills';
import { projects } from '@/data/projects';

/** Interactive "What I work across" — areas of experience, not services. */
export default function WorkAcross() {
  const [active, setActive] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const area = areas[active];

  const onKey = (e: React.KeyboardEvent, i: number) => {
    let next = i;
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') next = (i + 1) % areas.length;
    else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') next = (i - 1 + areas.length) % areas.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = areas.length - 1;
    else return;
    e.preventDefault();
    setActive(next);
    tabs.current[next]?.focus();
  };

  return (
    <section aria-labelledby="across-title" className="border-y border-line bg-white/50">
      <div className="page py-20 md:py-32">
        <div className="grid-page gap-y-6">
          <p className="t-meta col-span-4 flex items-center gap-2 text-muted md:col-span-3 md:pt-3">
            <span className="square" aria-hidden />
            Areas of experience
          </p>
          <h2 id="across-title" className="t-h2 col-span-4 md:col-span-9">
            What I work across
          </h2>
        </div>

        <div className="grid-page mt-12 gap-y-10 md:mt-16">
          <div role="tablist" aria-orientation="vertical" aria-label="Areas" className="col-span-4 flex flex-col md:col-span-6">
            {areas.map((a, i) => {
              const selected = i === active;
              return (
                <button
                  key={a.id}
                  ref={(el) => {
                    tabs.current[i] = el;
                  }}
                  role="tab"
                  id={`tab-${a.id}`}
                  aria-selected={selected}
                  aria-controls={`panel-${a.id}`}
                  tabIndex={selected ? 0 : -1}
                  onClick={() => setActive(i)}
                  onMouseEnter={() => setActive(i)}
                  onKeyDown={(e) => onKey(e, i)}
                  className={`group flex items-baseline gap-4 border-b border-line py-3 text-left transition-colors md:py-4 ${
                    selected ? 'text-ink' : 'text-ink/35 hover:text-ink/70'
                  }`}
                >
                  <span className={`square transition-transform duration-300 ${selected ? 'scale-100' : 'scale-0'}`} aria-hidden />
                  <span className="text-[clamp(1.6rem,3.6vw,3.2rem)] font-extrabold uppercase leading-none tracking-[-0.04em]">
                    {a.title}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="col-span-4 md:col-span-5 md:col-start-8">
            <div className="md:sticky md:top-[calc(var(--nav-h)+2rem)]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={area.id}
                  role="tabpanel"
                  id={`panel-${area.id}`}
                  aria-labelledby={`tab-${area.id}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.3 }}
                >
                  <p className="t-lead">{area.line}</p>
                  <p className="mt-5 text-muted">{area.detail}</p>
                  <ul className="mt-8 flex flex-wrap gap-2" aria-label={`${area.title} experience`}>
                    {area.items.map((it) => (
                      <li key={it} className="chip">
                        {it}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-10 border-t border-line pt-5">
                    <p className="t-meta mb-3 text-muted">Where it showed up</p>
                    <ul className="flex flex-wrap gap-x-5 gap-y-2">
                      {area.projects.map((slug) => {
                        const p = projects.find((x) => x.slug === slug);
                        if (!p) return null;
                        return (
                          <li key={slug}>
                            <Link href={`/case-studies/${slug}`} className="link-u font-medium">
                              {p.title}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
