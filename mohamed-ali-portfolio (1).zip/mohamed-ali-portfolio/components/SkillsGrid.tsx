import { skillGroups, tools, marketingApproach } from '@/data/skills';
import { Reveal } from './Reveal';

export default function SkillsGrid({ showTools = true }: { showTools?: boolean }) {
  return (
    <div>
      <div className="grid grid-cols-1 border-t border-ink sm:grid-cols-2 lg:grid-cols-5">
        {skillGroups.map((g, i) => (
          <Reveal
            key={g.title}
            delay={i * 0.05}
            y={14}
            className="border-b border-line py-8 sm:pr-6 lg:border-b-0 lg:border-r lg:px-5 lg:first:pl-0 lg:last:border-r-0"
          >
            <p className="t-meta text-muted">{String(i + 1).padStart(2, '0')}</p>
            <h3 className="mt-2 text-[1.35rem] font-extrabold uppercase leading-tight tracking-[-0.03em]">{g.title}</h3>
            <ul className="mt-5 space-y-1.5">
              {g.items.map((s) => (
                <li key={s} className="text-[0.95em]">
                  {s}
                </li>
              ))}
            </ul>
          </Reveal>
        ))}
      </div>

      {showTools && (
        <div className="grid-page mt-20 gap-y-8 md:mt-28">
          <div className="col-span-4 md:col-span-3">
            <h3 className="text-[1.6rem] font-extrabold uppercase tracking-[-0.03em]">Tools</h3>
            <p className="mt-3 max-w-[28ch] text-[15px] text-muted">{tools.note}</p>
          </div>
          <ul className="col-span-4 flex flex-wrap gap-2 md:col-span-9">
            {tools.items.map((t) => (
              <li key={t} className="chip">
                {t}
              </li>
            ))}
          </ul>

          <div className="col-span-4 mt-10 md:col-span-3">
            <h3 className="text-[1.6rem] font-extrabold uppercase tracking-[-0.03em]">Order of work</h3>
            <p className="mt-3 max-w-[28ch] text-[15px] text-muted">How I approach a marketing problem. Practical, in this order.</p>
          </div>
          <ol className="col-span-4 flex flex-wrap items-center gap-x-3 gap-y-3 md:col-span-9 md:mt-10">
            {marketingApproach.map((s, i) => (
              <li key={s} className="flex items-center gap-3">
                <span className="text-[clamp(1.2rem,2.2vw,1.8rem)] font-bold tracking-[-0.02em]">{s}</span>
                {i < marketingApproach.length - 1 && (
                  <span aria-hidden className="text-accent">
                    /
                  </span>
                )}
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
