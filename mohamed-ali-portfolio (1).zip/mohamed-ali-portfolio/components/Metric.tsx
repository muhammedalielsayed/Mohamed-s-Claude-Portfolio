import type { Metric as MetricT } from '@/lib/types';
import { metricTypeLabel } from '@/data/metrics';

/**
 * Results are solid. Documented figures are solid with an outlined badge.
 * Targets and objectives use outlined numerals and a dashed badge,
 * so a goal can never be mistaken for an achievement.
 */
export default function Metric({ metric, size = 'lg' }: { metric: MetricT; size?: 'lg' | 'md' }) {
  const isGoal = metric.type === 'target' || metric.type === 'objective';
  const badge =
    metric.type === 'result'
      ? 'bg-ink text-paper border-ink'
      : metric.type === 'documented'
        ? 'border-ink text-ink'
        : metric.type === 'target'
          ? 'border-dashed border-muted text-muted'
          : 'border-dotted border-muted text-muted';

  return (
    <div className={`flex h-full flex-col border-t pt-4 ${isGoal ? 'border-line' : 'border-ink'}`}>
      <span className={`t-meta inline-flex w-fit items-center gap-2 border px-2 py-1 ${badge}`}>
        {metric.type === 'result' && <span className="square" aria-hidden />}
        {metricTypeLabel[metric.type]}
      </span>
      <p
        className={`mt-5 font-extrabold leading-[0.9] tracking-[-0.045em] tabular-nums ${
          size === 'lg' ? 'text-[clamp(2.8rem,6vw,5.5rem)]' : 'text-[clamp(2.2rem,4vw,3.6rem)]'
        } ${isGoal ? 't-outline text-ink/70' : ''}`}
      >
        {metric.value}
      </p>
      <p className={`mt-3 max-w-[32ch] text-[0.9em] leading-snug ${isGoal ? 'text-muted' : ''}`}>{metric.label}</p>
      {metric.note && <p className="mt-2 text-[13px] leading-snug text-muted">{metric.note}</p>}
    </div>
  );
}
