import Link from 'next/link';
import { site } from '@/data/site';

export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="page grid-page gap-y-10 py-14 md:py-20">
        <div className="col-span-4 md:col-span-6">
          <p className="text-[clamp(2.6rem,7vw,6rem)] font-extrabold uppercase leading-[0.85] tracking-[-0.045em]">
            Mohamed
            <br />
            Ali
          </p>
        </div>
        <div className="col-span-2 md:col-span-3">
          <p className="t-meta mb-4 text-muted">Works across</p>
          <ul className="space-y-1">
            {site.footerDisciplines.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        </div>
        <div className="col-span-2 md:col-span-3">
          <p className="t-meta mb-4 text-muted">Pages</p>
          <ul className="space-y-1">
            {[...site.nav, ...site.secondaryNav].map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="link-u">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-span-4 flex flex-col justify-between gap-4 border-t border-line pt-6 md:col-span-12 md:flex-row">
          <p className="t-meta text-muted">© 2026 Mohamed Ali</p>
          <p className="t-meta text-muted">{site.location}</p>
          <a href="#top" className="t-meta link-u self-start">
            Back to top
          </a>
        </div>
      </div>
    </footer>
  );
}
