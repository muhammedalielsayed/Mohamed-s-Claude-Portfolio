import Link from 'next/link';
import SmartImage from './SmartImage';
import { Reveal, ImageReveal } from './Reveal';
import { site } from '@/data/site';

const chain = [
  'A customer support problem led me somewhere.',
  'A content problem led me somewhere else.',
  'A marketing problem taught me strategy.',
  'A team problem taught me systems.',
];

/** Home page "short story" block. */
export default function AboutIntro() {
  return (
    <section aria-labelledby="story-title" className="page py-20 md:py-32">
      <div className="grid-page gap-y-10">
        <div className="col-span-4 md:col-span-3">
          <p className="t-meta flex items-center gap-2 text-muted">
            <span className="square" aria-hidden />
            The short version
          </p>
          <ImageReveal className="relative mt-8 hidden aspect-[3/4] w-full md:block">
            <SmartImage src={site.images.casual} alt="Mohamed Ali, casual portrait" sizes="25vw" hint="casual.jpg" />
          </ImageReveal>
        </div>
        <div className="col-span-4 md:col-span-8 md:col-start-5">
          <Reveal>
            <h2 id="story-title" className="t-h3">
              I didn&apos;t really follow a career path.
              <br />
              I followed problems.
            </h2>
          </Reveal>
          <ol className="mt-10 border-t border-line md:mt-14">
            {chain.map((line, i) => (
              <li key={line} className="border-b border-line">
                <Reveal delay={i * 0.06} y={12} className="flex gap-6 py-4 md:py-5">
                  <span className="t-meta w-6 shrink-0 pt-[0.35em] text-muted">{String(i + 1).padStart(2, '0')}</span>
                  <span className="t-lead">{line}</span>
                </Reveal>
              </li>
            ))}
          </ol>
          <Reveal className="mt-10 grid gap-8 md:grid-cols-8 md:gap-6">
            <p className="t-body md:col-span-5">
              And somewhere along the way, I realized I enjoy figuring things out more than I enjoy staying inside one job description.
            </p>
            <div className="md:col-span-3 md:text-right">
              <Link href="/about" className="t-meta link-u">
                Read the long version
              </Link>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
