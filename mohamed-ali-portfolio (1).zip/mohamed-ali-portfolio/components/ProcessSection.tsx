import { process } from '@/data/skills';
import SectionHeader from './SectionHeader';
import { Reveal, DrawLine } from './Reveal';

const answers = [
  'Sometimes the answer is a campaign.',
  "Sometimes it's better communication.",
  "Sometimes it's a new workflow.",
  "Sometimes it's just a spreadsheet that finally makes sense.",
];

export default function ProcessSection() {
  return (
    <section aria-labelledby="process-title" className="page py-20 md:py-32">
      <SectionHeader label="How I think" id="process-title" title="How I work" />

      <div className="mt-14 md:mt-20">
        <DrawLine />
        <ol className="grid grid-cols-2 gap-x-4 md:grid-cols-6 md:gap-x-6">
          {process.map((step, i) => (
            <li key={step.n} className="relative border-b border-line py-6 md:border-b-0 md:py-8">
              <Reveal delay={i * 0.08} y={16}>
                <span className="block text-[2.2rem] font-extrabold leading-none tracking-[-0.04em] text-accent md:text-[2.8rem]">
                  {step.n}
                </span>
                <span className="mt-5 block text-[1.05rem] font-bold uppercase tracking-[-0.01em] md:text-[1.15rem]">
                  {step.title}
                </span>
                <span className="mt-2 block text-[15px] leading-snug text-muted md:text-base">{step.line}</span>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>

      <div className="grid-page mt-16 md:mt-24">
        <ul className="col-span-4 space-y-2 md:col-span-8 md:col-start-5">
          {answers.map((a, i) => (
            <li key={a}>
              <Reveal delay={i * 0.08} y={12}>
                <p className={`t-lead ${i === answers.length - 1 ? 'text-ink' : 'text-muted'}`}>{a}</p>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
