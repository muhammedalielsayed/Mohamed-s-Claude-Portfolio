'use client';
import Link from 'next/link';
import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import SmartImage from './SmartImage';
import { site } from '@/data/site';

const ease = [0.22, 1, 0.36, 1] as const;
const lines = ['I like', 'solving', 'problems.'];

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const imgY = useTransform(scrollYProgress, [0, 1], ['0%', reduce ? '0%' : '18%']);

  const rise = (i: number) =>
    reduce
      ? {}
      : {
          initial: { y: '105%' },
          animate: { y: '0%' },
          transition: { duration: 1.1, delay: 0.15 + i * 0.12, ease },
        };
  const fade = (d: number) =>
    reduce ? {} : { initial: { opacity: 0, y: 14 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.8, delay: d, ease } };

  return (
    <section ref={ref} aria-labelledby="hero-title" className="page relative pb-16 pt-6 md:pb-24 md:pt-10">
      {/* metadata row */}
      <motion.div {...fade(0.05)} className="grid-page t-meta border-b border-line pb-4 text-muted">
        <span className="col-span-2 text-ink md:col-span-3">{site.name}</span>
        <span className="col-span-2 md:col-span-2">{site.location}</span>
        <span className="col-span-4 mt-2 md:col-span-5 md:mt-0">{site.disciplines.join(' / ')}</span>
        <span className="col-span-4 mt-2 flex items-center gap-2 md:col-span-2 md:mt-0 md:justify-end">
          <span className="square" aria-hidden />
          Now: {site.currentRole}, {site.currentCompany}
        </span>
      </motion.div>

      <div className="relative mt-10 md:mt-14">
        <h1 id="hero-title" className="t-hero relative z-10">
          {lines.map((l, i) => (
            <span key={l} className="block overflow-hidden pb-[0.04em]">
              <motion.span className="block" {...rise(i)}>
                {l}
              </motion.span>
            </span>
          ))}
        </h1>

        {/* Portrait — floats beside the short lines on large screens */}
        <motion.div
          {...fade(0.6)}
          className="relative ml-auto mt-10 aspect-[4/5] w-[62%] overflow-hidden sm:w-[45%] lg:absolute lg:right-0 lg:top-0 lg:mt-0 lg:w-[22%]"
        >
          <motion.div className="absolute inset-[-10%_0]" style={{ y: imgY }}>
            <SmartImage
              src={site.images.hero}
              alt="Portrait of Mohamed Ali"
              sizes="(min-width: 1024px) 22vw, 60vw"
              priority
              hint="Portrait — hero.jpg"
            />
          </motion.div>
        </motion.div>
      </div>

      <div className="grid-page mt-10 gap-y-8 md:mt-16">
        <motion.p {...fade(0.75)} className="t-h3 col-span-4 md:col-span-6">
          Marketing was just where I started.
        </motion.p>
        <motion.div {...fade(0.9)} className="col-span-4 md:col-span-5 md:col-start-8">
          <p className="t-body text-[1.1em] leading-snug">
            I work across marketing, content, accounts, business and systems to turn messy problems into clear, workable solutions.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/work" className="btn btn-solid">
              View work
            </Link>
            <Link href="/about" className="btn btn-line">
              About me
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
