import CaseVisual from './CaseVisual';
import { Reveal } from './Reveal';
import type { Block } from '@/lib/types';

/** Sticky label on the left, content on the right. */
export default function CaseStudySection({
  number,
  label,
  block,
  children,
}: {
  number: string;
  label: string;
  block?: Block;
  children?: React.ReactNode;
}) {
  const id = `section-${number}`;
  return (
    <section aria-labelledby={id} className="page">
      <div className="grid-page gap-y-6 border-t border-line py-14 md:py-24">
        <div className="col-span-4 md:col-span-3">
          <div className="md:sticky md:top-[calc(var(--nav-h)+2rem)]">
            <span className="block text-[2rem] font-extrabold leading-none tracking-[-0.04em] md:text-[2.6rem]" style={{ color: 'var(--project-text)' }}>
              {number}
            </span>
            <h2 id={id} className="t-meta mt-3">
              {label}
            </h2>
          </div>
        </div>
        <div className="col-span-4 md:col-span-8 md:col-start-5">
          {block && (
            <Reveal>
              {block.text.map((t, i) => (
                <p key={i} className={i === 0 ? 't-lead' : 't-body mt-5'}>
                  {t}
                </p>
              ))}
              {block.listLabel && <p className="t-meta mt-10 text-muted">{block.listLabel}</p>}
              {block.list && (
                <ul className={`grid grid-cols-1 gap-x-8 border-t border-ink sm:grid-cols-2 ${block.listLabel ? 'mt-4' : block.text.length ? 'mt-8' : ''}`}>
                  {block.list.map((l) => (
                    <li key={l} className="flex gap-3 border-b border-line py-3">
                      <span aria-hidden className="mt-[0.6em] h-1.5 w-1.5 shrink-0" style={{ background: 'var(--project)' }} />
                      <span>{l}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Reveal>
          )}
          {block?.visual && (
            <Reveal className="mt-12 md:mt-16">
              <CaseVisual visual={block.visual} />
            </Reveal>
          )}
          {children}
        </div>
      </div>
    </section>
  );
}
