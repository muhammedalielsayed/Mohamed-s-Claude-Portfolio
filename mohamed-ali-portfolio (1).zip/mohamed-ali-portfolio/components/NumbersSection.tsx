import Link from 'next/link';
import Metric from './Metric';
import SectionHeader from './SectionHeader';
import { Reveal } from './Reveal';
import { metricGroups } from '@/data/metrics';

export default function NumbersSection() {
  return (
    <section aria-labelledby="numbers-title" className="page py-20 md:py-32">
      <SectionHeader
        label="Documented only"
        id="numbers-title"
        title="A few numbers"
        intro={
          <p className="text-muted">
            Only figures I can point to. Results are solid. Targets are outlined, because a goal isn&apos;t an achievement.
          </p>
        }
      />

      <div className="mt-14 space-y-16 md:mt-20 md:space-y-24">
        {metricGroups.map((g) => (
          <div key={g.slug} className="grid-page gap-y-8">
            <div className="col-span-4 md:col-span-3">
              <Link href={`/case-studies/${g.slug}`} className="text-[1.6rem] font-extrabold uppercase tracking-[-0.03em] hover:text-accent-ink">
                {g.project}
              </Link>
              <p className="t-meta mt-2 max-w-[24ch] text-muted">{g.source}</p>
            </div>
            <div
              className={`col-span-4 grid gap-x-6 gap-y-10 md:col-span-9 ${
                g.metrics.length > 2 ? 'grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2'
              }`}
            >
              {g.metrics.map((m, i) => (
                <Reveal key={m.label} delay={i * 0.06} y={16}>
                  <Metric metric={m} size={g.metrics.length > 2 ? 'md' : 'lg'} />
                </Reveal>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
