/** Consistent section opener: small label on the left, large heading on the grid. */
export default function SectionHeader({
  label,
  title,
  id,
  intro,
  tone = 'ink',
}: {
  label: string;
  title: React.ReactNode;
  id?: string;
  intro?: React.ReactNode;
  tone?: 'ink' | 'paper';
}) {
  return (
    <div className="grid-page gap-y-6">
      <p className={`t-meta col-span-4 flex items-center gap-2 md:col-span-3 md:pt-3 ${tone === 'paper' ? 'text-paper/60' : 'text-muted'}`}>
        <span className="square" aria-hidden />
        {label}
      </p>
      <div className="col-span-4 md:col-span-9">
        <h2 id={id} className="t-h2">
          {title}
        </h2>
        {intro && <div className="t-body mt-6 md:mt-8">{intro}</div>}
      </div>
    </div>
  );
}
