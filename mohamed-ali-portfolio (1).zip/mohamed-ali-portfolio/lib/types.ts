export type MetricType = 'result' | 'documented' | 'target' | 'objective';

export type Metric = {
  value: string;
  label: string;
  type: MetricType;
  note?: string;
};

export type Visual =
  | { kind: 'flow'; steps: string[]; caption?: string }
  | { kind: 'statement'; text: string; attribution?: string }
  | { kind: 'compare'; left: { title: string; points: string[] }; right: { title: string; points: string[] }; caption?: string }
  | { kind: 'themes'; items: string[]; caption?: string }
  | { kind: 'framework'; steps: string[]; caption?: string }
  | { kind: 'structure'; columns: { title: string; items: string[] }[]; caption?: string }
  | { kind: 'scatter'; sources: string[]; outcome: string; caption?: string };

export type Block = {
  /** Overrides the default section label (e.g. "CONTENT SYSTEM"). */
  label?: string;
  text: string[];
  list?: string[];
  /** Optional small caption shown above the list. */
  listLabel?: string;
  visual?: Visual;
};

export type GalleryLayout = 'full' | 'two' | 'three' | 'screenshot' | 'mobile' | 'dashboard';

export type GalleryBlock = {
  layout: GalleryLayout;
  images: string[];
  alts?: string[];
  caption?: string;
};

export type ResultType = 'documented' | 'approximate' | 'target' | 'mixed' | 'none';

export type Project = {
  slug: string;
  title: string;
  subtitle: string;
  number: string;
  category: string;
  industry: string;
  role: string;
  /** One line used on cards: the problem this project was really about. */
  problemLine: string;
  summary: string;
  context: Block;
  problem?: Block;
  myRole?: Block;
  thinking?: Block;
  solution?: Block;
  execution?: Block;
  results?: Metric[];
  resultsLabel?: string;
  resultsNote?: string;
  resultType: ResultType;
  takeaway: Block;
  closing?: string;
  tags: string[];
  accent: string;
  /** Darker variant of accent used for text so contrast stays readable. */
  accentText: string;
  heroImage: string;
  /** Simple list of images. Used for the auto-layout gallery if `gallery` is not set. */
  images: string[];
  /** Optional explicit gallery layout. Add/replace image paths here, no layout code needed. */
  gallery?: GalleryBlock[];
};

export type ExperienceEntry = {
  id: string;
  chapter: string;
  title: string;
  subtitle?: string;
  roles: string[];
  story: string[];
  current?: boolean;
  side?: { title: string; roles: string[]; story: string };
  projectSlug?: string;
};
