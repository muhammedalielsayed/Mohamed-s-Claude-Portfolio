import type { ExperienceEntry } from '@/lib/types';

/** No exact dates on purpose. Order follows the real sequence. */
export const experience: ExperienceEntry[] = [
  {
    id: 'early',
    chapter: '01',
    title: 'Early work',
    roles: ['Customer-facing work', 'Printing'],
    story: [
      'I started working young. Not in marketing.',
      'One early job was near an English lesson. The goal was football boots and gloves.',
      'Later, in secondary school, I worked at a printing place run by friends. Customers, basic production, and learning what people actually want versus what they ask for.',
    ],
  },
  {
    id: 'bassthalk-support',
    chapter: '02',
    title: 'Bassthalk',
    subtitle: 'University years',
    roles: ['Customer Support', 'Moderation', 'Team responsibilities'],
    story: [
      'Joined as customer support. Became one of the stronger members of the team, then moved into moderation and team responsibilities.',
      'Students, parents, teachers. Every kind of problem, every day.',
    ],
    projectSlug: 'bassthalk',
  },
  {
    id: 'agency',
    chapter: '03',
    title: 'Marketing agency work',
    roles: ['Content', 'Strategy', 'Accounts'],
    story: [
      'The same owner started a marketing agency. I joined knowing very little about marketing.',
      'Most of what I know started here. Doing it, testing it, seeing what failed.',
    ],
  },
  {
    id: 'pixel',
    chapter: '04',
    title: 'Pixel',
    roles: ['Creative / Art direction exposure'],
    story: [
      'When the manager left, the owner asked me to take on something close to a mini art director role.',
      'I said yes. With basic CapCut, limited Photoshop, and color blindness.',
      'The company eventually closed.',
    ],
  },
  {
    id: 'bassthalk-content',
    chapter: '05',
    title: 'Bassthalk, again',
    roles: ['Content Creator', 'TikTok', 'Social Media'],
    story: [
      'Came back as a content creator. TikTok and social content.',
      'Some campaigns performed very strongly. This is where the biggest numbers on this site come from.',
    ],
    projectSlug: 'bassthalk',
  },
  {
    id: 'ohana',
    chapter: '06',
    title: 'Ohana Marketing',
    roles: ['Multiple client accounts'],
    story: [
      'Worked across client accounts including Kovo, Absel and burger-related accounts.',
      'After that I stayed mainly with Bassthalk for a period, then left.',
    ],
  },
  {
    id: 'skilled',
    chapter: '07',
    title: 'SKILLED',
    roles: ['Saudi + Egyptian accounts', 'Content', 'Strategy', 'Client work'],
    story: ['Two markets on the same desk. Content, strategy, social media and client work.'],
    projectSlug: 'skilled',
    side: {
      title: 'RLVNT',
      roles: ['Co-founder', 'Marketing'],
      story: 'At the same time, a clothing brand with friends. It didn’t become the business we intended. It taught me the founder side.',
    },
  },
  {
    id: 'elhesa',
    chapter: '08',
    title: 'ELHESA',
    subtitle: 'Now',
    current: true,
    roles: ['Account Management', 'Social Media Coordination', 'Technology Coordination', 'Platform Testing', 'Systems / Workflows'],
    story: [
      'Account Manager. In practice: requirements, follow-up, testing, and making sure information moves between teams without getting lost.',
    ],
    projectSlug: 'elhesa',
  },
];
