import type { Project } from '@/lib/types';

/**
 * PROJECT DATA
 * ------------
 * To add screenshots: drop files into /public/images/projects/<slug>/ using the
 * names below (hero.jpg, 01.jpg, 02.jpg ...). Missing images show a placeholder.
 * To change a layout, edit the `gallery` array. No component changes needed.
 *
 * Truth rule: every number here is documented. Targets and objectives are
 * labelled as such and never shown as results.
 */

const img = (slug: string, n: number, ext = 'jpg') =>
  `/images/projects/${slug}/${String(n).padStart(2, '0')}.${ext}`;
const hero = (slug: string) => `/images/projects/${slug}/hero.jpg`;

export const projects: Project[] = [
  // ------------------------------------------------------------------ 01
  {
    slug: 'bassthalk',
    number: '01',
    title: 'Bassthalk',
    subtitle: 'Turning education into content students actually wanted to watch.',
    category: 'Flagship case study',
    industry: 'Education / EdTech',
    role: 'Content / Social / Support',
    problemLine: 'Education content that feels like homework gets scrolled past.',
    summary:
      'I started here in customer support and ended up making the content. Same students, two sides: their problems in the inbox, their attention on the feed.',
    context: {
      text: [
        'Bassthalk is a secondary-level e-learning platform in Egypt.',
        "I didn't join as a marketer. I joined as customer support.",
        'Over time that turned into moderation, team responsibilities, and eventually content: TikTok, social media, campaigns.',
      ],
    },
    problem: {
      text: [
        'Education content can easily become repetitive.',
        'Teacher talks. Student listens. Lesson ends.',
        'The challenge was making educational content feel native to the platforms students were already using, without losing the education part.',
      ],
    },
    myRole: {
      text: [
        'Support came first. I became one of the stronger members of the support team, then took on moderation and team responsibilities.',
        "I also worked on a work group and the teacher/owner's page. I tried a different response style there, and it generated strong reach.",
        'Later I came back as a content creator, focused on TikTok and social content.',
      ],
      list: ['Customer Support', 'Moderation', 'Content Creator', 'Social Media / TikTok'],
    },
    thinking: {
      text: [
        'Stop treating students as an audience waiting for a lesson.',
        "Build the content around what's already in their day.",
      ],
      list: [
        'Relatable situations',
        'Student culture',
        'Humor',
        'Teacher personality',
        'Challenges',
        'Questions and comments',
        'Study problems',
        'Behind the scenes',
        'Educational entertainment',
      ],
      visual: {
        kind: 'statement',
        text: 'Build a strong, trusted brand. Position Bassthalk as a student-friendly, innovative secondary-level e-learning platform in Egypt.',
        attribution: 'Documented one-year campaign direction',
      },
    },
    solution: {
      label: 'Content system',
      text: [
        'Formats a student could recognize in two seconds.',
        'Repeatable, so every week didn’t start from zero.',
      ],
      visual: {
        kind: 'themes',
        caption: 'Content themes developed / worked on',
        items: [
          'معلومة في 30 ثانية',
          'Exam tips',
          'Study challenges',
          'افهمها كأنك طفل',
          'Common exam mistakes',
          'Replying to comments with videos',
          'Memory techniques',
          'Effective study methods',
          'Comedic study situations',
          'Expected questions',
          'Study myths',
          'Comparing study methods',
          'BTS',
          'Student situations',
          'Teacher personality',
          'Parent content',
          'Study With Me',
          'Student challenges',
          'Teacher introductions',
          'Educational entertainment',
        ],
      },
      listLabel: 'Content areas in the one-year strategy',
      list: [
        'Subscription promotion',
        'Teacher awareness',
        'BTS',
        'Meet Your Teacher',
        'Customer support comedy',
        'UGC',
        'Special-day campaigns',
        'Teacher collaborations',
        'Student series',
        'Study content',
        'Parent content',
        'Gamification',
        'Study With Me',
        'Challenges',
        'Community',
        'Teacher personality',
      ],
    },
    execution: {
      text: [
        'TikTok first. Short, fast, recognizable.',
        'Replying to student comments with videos. Turning common exam mistakes into content. Putting the teacher’s personality on screen, not only the teacher’s knowledge.',
        'Some formats landed. Some didn’t. Testing them was the point.',
      ],
    },
    resultType: 'mixed',
    resultsLabel: 'Documented results',
    resultsNote:
      'Approximate documented performance. No engagement rate, follower growth, revenue or conversion figures are claimed.',
    results: [
      { value: '1.5M–2M+', label: 'Approximate views on one campaign', type: 'result' },
      {
        value: '7M–8M+',
        label: 'Approximate views across two documented videos featuring Mr. Mohamed Salah',
        type: 'result',
      },
      {
        value: '100,000',
        label: 'Followers in one year',
        type: 'objective',
        note: 'Campaign objective in the one-year strategy. Not a reported result.',
      },
    ],
    takeaway: {
      label: 'What I learned',
      text: [
        "Students don't skip education. They skip boring.",
        'Support showed me what students struggle with. Content showed me how to get their attention for it.',
      ],
    },
    closing:
      "The best educational content isn't always the content with the most information. Sometimes it's the content that makes the student stop scrolling.",
    tags: ['TikTok', 'Education', 'Content strategy', 'Community', 'Customer support'],
    accent: '#3D6BE0',
    accentText: '#2448A8',
    heroImage: hero('bassthalk'),
    images: [img('bassthalk', 1), img('bassthalk', 2), img('bassthalk', 3)],
    gallery: [
      { layout: 'full', images: [img('bassthalk', 1)], caption: 'Campaign key visual' },
      {
        layout: 'mobile',
        images: [img('bassthalk', 2), img('bassthalk', 3), img('bassthalk', 4)],
        caption: 'TikTok content',
      },
      { layout: 'two', images: [img('bassthalk', 5), img('bassthalk', 6)], caption: 'Teacher content' },
      {
        layout: 'three',
        images: [img('bassthalk', 7), img('bassthalk', 8), img('bassthalk', 9)],
        caption: 'Student series and challenges',
      },
      { layout: 'screenshot', images: [img('bassthalk', 10)], caption: 'Content plan' },
    ],
  },

  // ------------------------------------------------------------------ 02
  {
    slug: 'elhesa',
    number: '02',
    title: 'ELHESA',
    subtitle: 'Where requirements stop getting lost between teams.',
    category: 'Current role',
    industry: 'Education / EdTech',
    role: 'Account Manager',
    problemLine: 'Information scattered across messages. Nobody sure who owns the next step.',
    summary:
      'My current role. Account management, which in practice means standing between teams and making sure requirements arrive where they need to.',
    context: {
      text: [
        'ELHESA works in education.',
        'My title is Account Manager.',
        'The work crosses into social media, technology coordination, platform testing and internal workflows.',
      ],
    },
    problem: {
      text: [
        'A single request can pass through several people before it becomes something real.',
        'When that handoff lives in scattered messages, information gets lost and ownership gets unclear.',
      ],
      visual: {
        kind: 'flow',
        steps: ['Account Manager', 'Teacher', 'Data Entry', 'Support', 'Platform / System'],
        caption: 'One workflow. Five handoffs.',
      },
    },
    myRole: {
      text: ['Account Manager. The job description is short. The actual list is longer:'],
      list: [
        'Following the social media team',
        'Communicating requirements between teams',
        'Translating technology-related requirements',
        'Following up with technical teams',
        'Testing platform functionality',
        'Reporting issues',
        'Helping teams understand requirements',
        'Supporting workflow organization',
        'Helping build internal systems',
        'Google Forms, Google Sheets and data workflows',
      ],
    },
    thinking: {
      text: [
        "The issue usually isn't that nobody cares. It's that nobody can see the whole path.",
        'So the questions became simple: where does this information enter, who touches it next, and where does it end up?',
      ],
    },
    solution: {
      text: [
        'Structured Google Forms where information enters.',
        'Google Sheets as the shared record.',
        'A clear handoff between each stage.',
      ],
      visual: {
        kind: 'statement',
        text: "I didn't build a complex software system. I noticed information was getting scattered and helped turn the process into a structured workflow.",
      },
    },
    execution: {
      text: ['Day to day, it’s less dramatic than it sounds.'],
      list: [
        'Requirement gathering',
        'Follow-up with technical teams',
        'Testing platform functionality',
        'Reporting issues clearly',
        'Keeping the social media team aligned',
        'Tracking execution',
      ],
    },
    resultType: 'none',
    takeaway: {
      label: 'What I learned',
      text: [
        'Most of the job is turning “there’s a problem” into “here’s exactly what needs to happen next.”',
        'Most problems between teams aren’t technical. They’re handoffs.',
      ],
    },
    tags: ['Account management', 'Workflows', 'Google Forms', 'Google Sheets', 'Platform testing'],
    accent: '#6A4BF2',
    accentText: '#4A2FC4',
    heroImage: hero('elhesa'),
    images: [img('elhesa', 1), img('elhesa', 2)],
    gallery: [
      { layout: 'dashboard', images: [img('elhesa', 1)], caption: 'Workflow sheet' },
      { layout: 'screenshot', images: [img('elhesa', 2)], caption: 'Structured form' },
      { layout: 'two', images: [img('elhesa', 3), img('elhesa', 4)] },
    ],
  },

  // ------------------------------------------------------------------ 03
  {
    slug: 'studyhub',
    number: '03',
    title: 'StudyHub',
    subtitle: 'A marketing role that kept turning into business questions.',
    category: 'Project / team role',
    industry: 'Education / EdTech',
    role: 'Head of Marketing & Growth',
    problemLine: 'Another post doesn’t help if the business underneath isn’t clear.',
    summary:
      'Teachers, students, digital products, subdomains, templates. Before planning content, the question was: how does this business actually work?',
    context: {
      text: [
        'StudyHub is an education platform built around teachers and students.',
        'The business involved teachers, students, digital products, subdomains, templates, marketing, sales, operations and technology.',
      ],
    },
    problem: {
      text: [
        'It’s easy to treat marketing as “make another post.”',
        'With this many moving parts, a post doesn’t fix much if the business underneath isn’t clear.',
      ],
      visual: { kind: 'statement', text: 'How does the business actually work?' },
    },
    myRole: {
      text: [
        'In the documented team structure, I’m listed as Head of Marketing & Growth.',
        'This was a project team role, separate from my current role at ELHESA.',
      ],
      list: [
        'Brand building',
        'Managing the marketing team',
        'Content creation',
        'Strategy development',
        'Social media management',
        'Paid ads',
        'Client acquisition',
        'Audience trust-building',
        'Growing StudyHub in the market',
      ],
    },
    thinking: {
      text: ['Map the business before planning the marketing. Three areas, each with its own responsibilities and KPIs.'],
      visual: {
        kind: 'structure',
        caption: 'Documented team structure',
        columns: [
          {
            title: 'Marketing',
            items: ['Brand building', 'Content', 'Ads', 'Funnels', 'Landing pages', 'WhatsApp / DM', 'Analytics', 'Market study', 'KPIs'],
          },
          {
            title: 'Technology / Product',
            items: ['Platform', 'Dashboards', 'Database', 'Servers', 'Security', 'Bug fixing', 'UX', 'Technical support', 'KPIs'],
          },
          {
            title: 'Business / Administration',
            items: ['Growth', 'Partnerships', 'Operations', 'Pricing', 'Sales', 'Financials', 'Expansion', 'KPIs'],
          },
        ],
      },
    },
    solution: {
      label: 'Marketing work',
      text: ['The marketing side, documented across:'],
      list: ['Brand', 'Content', 'Paid ads', 'Funnels', 'Landing pages', 'WhatsApp / DM', 'Analytics', 'Market study'],
    },
    execution: {
      label: 'Beyond marketing',
      text: ['And the parts that usually sit outside a marketing brief:'],
      list: ['Team structure', 'Business structure', 'Pricing', 'Partnerships', 'Operations', 'Growth'],
    },
    resultType: 'none',
    takeaway: {
      label: 'What I learned',
      text: [
        'Marketing gets easier when you understand the business model.',
        'And harder to fake when you don’t.',
      ],
    },
    tags: ['Growth', 'Business structure', 'Funnels', 'Paid ads', 'Team structure'],
    accent: '#D9822B',
    accentText: '#9A5410',
    heroImage: hero('studyhub'),
    images: [img('studyhub', 1), img('studyhub', 2)],
    gallery: [
      { layout: 'full', images: [img('studyhub', 1)] },
      { layout: 'screenshot', images: [img('studyhub', 2)], caption: 'Landing page' },
      { layout: 'three', images: [img('studyhub', 3), img('studyhub', 4), img('studyhub', 5)] },
    ],
  },

  // ------------------------------------------------------------------ 04
  {
    slug: 'seagate',
    number: '04',
    title: 'SeaGate',
    subtitle: 'Making logistics sound like a business decision, not a lecture.',
    category: 'B2B',
    industry: 'Logistics / B2B',
    role: 'Content strategy / Social / Paid media',
    problemLine: 'Shipping, customs, ports, delays. Hard to explain, easy to ignore.',
    summary:
      'SeaGate / SeaGate Express. Complex logistics topics translated into the questions a business owner actually asks.',
    context: {
      text: ['SeaGate / SeaGate Express works in logistics, a B2B space.', 'Shipping. Customs. Ports. Delays. Costs. Warehousing. Supply chain.'],
    },
    problem: {
      text: [
        'Logistics is complicated.',
        'A business owner doesn’t want a lesson on freight. They want to know what it means for their shipment.',
      ],
    },
    myRole: {
      text: ['Worked across the marketing side of the account.'],
      list: ['Content strategy', 'Social media', 'B2B marketing', 'Paid media'],
    },
    thinking: {
      text: ['Translate logistics topics into business questions.'],
      list: [
        'Which shipping method makes sense for your business?',
        'Why do shipments get delayed?',
        'How do you track your shipment?',
        'When should you use sea, air or land freight?',
      ],
      visual: { kind: 'framework', steps: ['Educate', 'Relate', 'Build trust', 'Convert'], caption: 'Content framework' },
    },
    solution: {
      text: ['One principle shaped the content: help the business choose, instead of pushing one answer.'],
      visual: {
        kind: 'statement',
        text: 'There is no universally “best” shipping method. The right option depends on the business.',
      },
    },
    execution: {
      text: ['Reels built around those questions, promoted through Meta Ads.'],
    },
    resultType: 'documented',
    resultsLabel: 'Documented Meta Ads data',
    resultsNote:
      'Reporting period: 2026-05-21 to 2026-05-25. Figures are reach and cost per result only. Reach is not converted into views or impressions.',
    results: [
      { value: '8,262', label: 'Reach — Reel 2', type: 'documented' },
      { value: '7.75 EGP', label: 'Cost per result — Reel 2', type: 'documented', note: 'Exact: 7.75478092 EGP' },
      { value: '4,009', label: 'Reach — Reel 1', type: 'documented' },
      { value: '7.07 EGP', label: 'Cost per result — Reel 1', type: 'documented', note: 'Exact: 7.07158892 EGP' },
    ],
    takeaway: {
      label: 'What I learned',
      text: ['In B2B, clarity does most of the persuading.', 'Complicated industries don’t need simpler businesses. They need simpler explanations.'],
    },
    tags: ['B2B', 'Logistics', 'Meta Ads', 'Reels', 'Content framework'],
    accent: '#1D4E89',
    accentText: '#163C6B',
    heroImage: hero('seagate'),
    images: [img('seagate', 1), img('seagate', 2)],
    gallery: [
      { layout: 'mobile', images: [img('seagate', 1), img('seagate', 2)], caption: 'Reel 1 and Reel 2' },
      { layout: 'dashboard', images: [img('seagate', 3)], caption: 'Meta Ads Manager' },
      { layout: 'two', images: [img('seagate', 4), img('seagate', 5)] },
    ],
  },

  // ------------------------------------------------------------------ 05
  {
    slug: 'booklet',
    number: '05',
    title: 'Booklet',
    subtitle: 'Selling a digital book to students who already trust paper.',
    category: 'Campaign',
    industry: 'Education / Digital products',
    role: 'Marketing / Campaign',
    problemLine: 'You’re not competing with another product. You’re competing with a habit.',
    summary: 'Digital school books. The hard part wasn’t the features. Students already have books they trust.',
    context: {
      text: ['Booklet sells digital school books.', 'Its audience already has a habit: the physical book.'],
    },
    problem: {
      text: [
        'Listing features wasn’t going to be enough.',
        'The product needed a behavioral reason. Why would a student change something they already do?',
      ],
      visual: {
        kind: 'compare',
        left: { title: 'Physical book', points: ['Familiar', 'Already trusted', 'Already on the desk'] },
        right: { title: 'Digital book', points: ['Convenience', 'Accessibility', 'A digital experience'] },
        caption: 'The core comparison',
      },
    },
    myRole: {
      text: ['Worked on the marketing side of the campaign: angles, content directions and offers.'],
    },
    thinking: {
      text: ['The content angles:'],
      list: ['Convenience', 'Accessibility', 'Digital experience', 'Offers', 'Bundles', 'Pricing', 'Teacher books', 'Student behavior'],
    },
    execution: {
      label: 'Offers',
      text: ['Historical campaign examples:'],
      list: ['20% off for the first 100', '25% mathematics flash sale', '25% bundle offer'],
    },
    resultType: 'target',
    resultsLabel: 'Campaign targets',
    resultsNote: 'These were goals in the campaign plan. They are not reported results.',
    results: [
      { value: '5,000', label: 'Followers', type: 'target' },
      { value: '10,000', label: 'Reach per post', type: 'target' },
      { value: '500', label: 'Sales', type: 'target' },
      { value: '20', label: 'Contracted stores', type: 'target' },
    ],
    takeaway: {
      label: 'What I learned',
      text: ['A feature list explains a product.', 'A reason changes a habit.'],
    },
    tags: ['Digital products', 'Offers', 'Campaign planning', 'Education'],
    accent: '#B89B5E',
    accentText: '#7A6232',
    heroImage: hero('booklet'),
    images: [img('booklet', 1), img('booklet', 2)],
    gallery: [
      { layout: 'full', images: [img('booklet', 1)] },
      { layout: 'two', images: [img('booklet', 2), img('booklet', 3)], caption: 'Physical vs digital' },
      { layout: 'three', images: [img('booklet', 4), img('booklet', 5), img('booklet', 6)], caption: 'Offers' },
    ],
  },

  // ------------------------------------------------------------------ 06
  {
    slug: 'skilled',
    number: '06',
    title: 'SKILLED',
    subtitle: 'Saudi and Egyptian accounts, side by side.',
    category: 'Agency',
    industry: 'Marketing',
    role: 'Social / Strategy / Content / Client work',
    problemLine: 'What worked in one market gets copied into the next one.',
    summary: 'Two markets on the same desk. The lesson was in the difference between them.',
    context: {
      text: ['At SKILLED I worked on Saudi and Egyptian accounts.', 'Content, strategy, social media and client work.'],
    },
    problem: {
      text: ['It’s tempting to reuse what worked.', 'An idea performs in one market, so it gets copied into the next one.'],
    },
    myRole: {
      text: ['Worked across the accounts on:'],
      list: ['Social media', 'Strategy', 'Content', 'Client work'],
    },
    thinking: {
      text: ['Different markets have:'],
      list: [
        'Different audiences',
        'Different cultural contexts',
        'Different buying behavior',
        'Different business needs',
        'Different communication expectations',
      ],
      visual: { kind: 'statement', text: 'Context matters.' },
    },
    solution: {
      text: ['Start every idea from the market it’s going into, not the market it came from.'],
    },
    resultType: 'none',
    takeaway: {
      label: 'What I learned',
      text: ['A good idea in the wrong context is just a wrong idea.'],
    },
    tags: ['Saudi', 'Egypt', 'Client work', 'Strategy'],
    accent: '#6B6B63',
    accentText: '#4A4A44',
    heroImage: hero('skilled'),
    images: [img('skilled', 1), img('skilled', 2)],
    gallery: [
      { layout: 'two', images: [img('skilled', 1), img('skilled', 2)], caption: 'Saudi / Egypt' },
      { layout: 'three', images: [img('skilled', 3), img('skilled', 4), img('skilled', 5)] },
    ],
  },

  // ------------------------------------------------------------------ 07
  {
    slug: 'rlvnt',
    number: '07',
    title: 'RLVNT',
    subtitle: 'A clothing brand with friends. It didn’t become the business we intended.',
    category: 'Own project',
    industry: 'Fashion / E-commerce',
    role: 'Co-founder / Marketing',
    problemLine: 'A good-looking brand is not automatically a viable business.',
    summary: 'The first time I was on the founder side instead of the client side. The most useful thing I’ve done that didn’t work.',
    context: {
      label: 'The experiment',
      text: [
        'RLVNT was a clothing brand I started with friends.',
        'For the first time, I wasn’t the agency or the employee. I was on the founder side.',
      ],
    },
    problem: {
      label: 'The idea',
      text: ['Build a clothing brand. Do the brand work properly: strategy, research, content, story.'],
    },
    myRole: {
      text: ['Co-founder, on the marketing side.'],
    },
    solution: {
      label: 'What we tried',
      text: ['Most of the playbook I’d used for clients:'],
      list: ['Brand strategy', 'Competitor research', 'Social media', 'Content', 'Offers', 'UGC', 'Storytelling', 'Direct sales'],
    },
    execution: {
      label: 'What didn’t work',
      text: [
        'It didn’t become the business we intended.',
        'I’m not going to dress that up.',
        'Looking back, a lot of what mattered most had nothing to do with how the brand looked.',
      ],
    },
    resultType: 'none',
    takeaway: {
      label: 'What I learned',
      text: [],
      list: [
        'Ideas aren’t businesses.',
        'Distribution matters.',
        'Execution matters.',
        'Team alignment matters.',
        'Cash flow matters.',
        'A good-looking brand is not automatically a viable business.',
      ],
    },
    closing:
      'Working with clients, you see the marketing. Building your own thing, you see everything the marketing was sitting on.',
    tags: ['Founder side', 'Fashion', 'E-commerce', 'Brand'],
    accent: '#2A2724',
    accentText: '#2A2724',
    heroImage: hero('rlvnt'),
    images: [img('rlvnt', 1), img('rlvnt', 2)],
    gallery: [
      { layout: 'full', images: [img('rlvnt', 1)] },
      { layout: 'three', images: [img('rlvnt', 2), img('rlvnt', 3), img('rlvnt', 4)], caption: 'Content' },
      { layout: 'two', images: [img('rlvnt', 5), img('rlvnt', 6)] },
    ],
  },

  // ------------------------------------------------------------------ 08
  {
    slug: 'systems',
    number: '08',
    title: 'Systems & Workflows',
    subtitle: 'Some of my favorite work never goes on Instagram.',
    category: 'Compilation',
    industry: 'Internal / Operations',
    role: 'Systems / Process',
    problemLine: 'When information lives everywhere, everyone has to remember everything.',
    summary: 'Forms, sheets, SOPs, templates. The part of the work that doesn’t get posted, and the part I often enjoy most.',
    context: {
      text: ['A compilation, not a single project.', 'Systems-oriented work collected from different teams and roles.'],
    },
    problem: {
      text: ['Information scattered across five places means nobody has the full picture.'],
      visual: {
        kind: 'scatter',
        sources: ['WhatsApp', 'DMs', 'Calls', 'Random sheets', 'Messages'],
        outcome: 'One structured flow',
      },
    },
    thinking: {
      text: ['One rule I keep coming back to:'],
      visual: { kind: 'statement', text: 'A system should reduce the number of things people need to remember.' },
    },
    solution: {
      label: 'What it includes',
      text: ['Examples of the work:'],
      list: [
        'Google Forms',
        'Google Sheets',
        'Team workflows',
        'SOPs',
        'Employee evaluation systems',
        'Dashboards',
        'Reporting',
        'Team structures',
        'Pricing calculators',
        'Funnels',
        'Data organization',
        'Operational templates',
      ],
    },
    execution: {
      text: ['None of this is software engineering.', 'It’s forms, sheets, templates and clear ownership. Built so the next person doesn’t have to ask.'],
    },
    resultType: 'none',
    takeaway: {
      label: 'What I learned',
      text: ['Sometimes the answer is a campaign.', 'Sometimes it’s a spreadsheet that finally makes sense.'],
    },
    tags: ['Systems', 'SOPs', 'Google Sheets', 'Process design'],
    accent: '#1E8A5C',
    accentText: '#146242',
    heroImage: hero('systems'),
    images: [img('systems', 1), img('systems', 2)],
    gallery: [
      { layout: 'dashboard', images: [img('systems', 1)], caption: 'Dashboard' },
      { layout: 'screenshot', images: [img('systems', 2)], caption: 'SOP / template' },
      { layout: 'two', images: [img('systems', 3), img('systems', 4)] },
    ],
  },
];

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug);
}

export function getNextProject(slug: string) {
  const i = projects.findIndex((p) => p.slug === slug);
  return projects[(i + 1) % projects.length];
}

/** Other accounts and projects. Wording is deliberate: not every account was owned by me. */
export const otherWork = {
  intro:
    'Accounts and projects I’ve worked on, contributed to or supported, across agencies, teams and my own experiments. Not every one of them was mine to own.',
  accounts: ['Kovo', 'Absel', 'Burger-related accounts', 'Lazy Burger', 'Food Caravan', 'GUSTO'],
  industries: [
    'Education',
    'Restaurants',
    'Food brands',
    'Logistics',
    'Software',
    'Recruitment',
    'Charity',
    'Marketing agencies',
    'Teachers / Personal brands',
    'E-commerce',
    'Digital products',
  ],
};
