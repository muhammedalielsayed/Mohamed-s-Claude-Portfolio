import type { Metric } from '@/lib/types';

/**
 * "A few numbers" — documented figures only.
 * type: 'result' = approximate documented performance
 *       'documented' = exact figures from a documented source
 *       'target' / 'objective' = goals, never achievements
 */
export const metricGroups: { project: string; slug: string; source: string; metrics: Metric[] }[] = [
  {
    project: 'Bassthalk',
    slug: 'bassthalk',
    source: 'Approximate documented performance',
    metrics: [
      { value: '1.5M–2M+', label: 'Approximate campaign views', type: 'result' },
      { value: '7M–8M+', label: 'Approximate views across two documented videos featuring Mr. Mohamed Salah', type: 'result' },
    ],
  },
  {
    project: 'SeaGate',
    slug: 'seagate',
    source: 'Documented Meta Ads data, 2026-05-21 to 2026-05-25',
    metrics: [
      { value: '8,262', label: 'Documented reach — Reel 2', type: 'documented' },
      { value: '4,009', label: 'Documented reach — Reel 1', type: 'documented' },
    ],
  },
  {
    project: 'Booklet',
    slug: 'booklet',
    source: 'Campaign targets — not results',
    metrics: [
      { value: '5,000', label: 'Campaign follower target', type: 'target' },
      { value: '10,000', label: 'Reach target per post', type: 'target' },
      { value: '500', label: 'Sales target', type: 'target' },
      { value: '20', label: 'Contracted stores target', type: 'target' },
    ],
  },
];

export const metricTypeLabel: Record<Metric['type'], string> = {
  result: 'Result',
  documented: 'Documented',
  target: 'Target',
  objective: 'Objective',
};
