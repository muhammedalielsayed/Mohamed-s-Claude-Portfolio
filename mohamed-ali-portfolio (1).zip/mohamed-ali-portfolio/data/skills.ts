export const skillGroups = [
  {
    title: 'Strategy',
    items: ['Marketing Strategy', 'Positioning', 'Competitor Research', 'Audience Research', 'Buyer Personas', 'Funnels', 'Campaign Planning', 'Content Strategy'],
  },
  {
    title: 'Content',
    items: ['Copywriting', 'Scriptwriting', 'Creative Concepts', 'Social Media', 'TikTok', 'Reels', 'Carousels', 'Storytelling'],
  },
  {
    title: 'Business',
    items: ['Business Analysis', 'Pricing', 'Customer Journey', 'Monetization', 'Team Structures', 'Growth Thinking'],
  },
  {
    title: 'Systems',
    items: ['SOPs', 'Workflows', 'Google Sheets', 'Google Forms', 'Reporting', 'Process Design'],
  },
  {
    title: 'Account management',
    items: ['Client Communication', 'Requirement Gathering', 'Coordination', 'Follow-up', 'Execution Management'],
  },
];

export const tools = {
  note: 'Tools I’ve worked with. Some daily, some occasionally. Not an expert in all of them.',
  items: [
    'Google Sheets',
    'Google Forms',
    'Google Workspace',
    'Meta Business Suite',
    'Meta Ads Manager',
    'Canva',
    'CapCut',
    'Notion',
    'Microsoft Office',
    'AI tools',
    'Analytics / reporting tools',
  ],
};

export const marketingApproach = ['Problem', 'Audience', 'Message', 'Channel', 'Content', 'Execution', 'Measurement', 'Improvement'];

/** "What I work across" — areas of experience, not services. */
export const areas = [
  {
    id: 'marketing',
    title: 'Marketing',
    line: 'Strategy, positioning, funnels, campaigns. Learned mostly by running them.',
    detail: 'I prefer a practical order: problem, audience, message, channel, content, execution, measurement, improvement.',
    items: ['Marketing strategy', 'Positioning', 'Competitor research', 'Audience research', 'Buyer personas', 'Funnels', 'Campaign planning', 'Paid media', 'Customer journeys', 'Performance analysis'],
    projects: ['bassthalk', 'studyhub', 'seagate', 'booklet', 'skilled'],
  },
  {
    id: 'content',
    title: 'Content',
    line: 'TikTok, reels, carousels, scripts. B2C and B2B.',
    detail: 'Students, teachers, food brands, logistics companies, a clothing brand. Different audiences, same question: why would anyone stop for this?',
    items: ['TikTok', 'Instagram', 'Facebook', 'Reels', 'Carousels', 'Static posts', 'Scripts', 'Campaign concepts', 'Educational content', 'Comedy', 'UGC', 'B2B content'],
    projects: ['bassthalk', 'seagate', 'skilled', 'rlvnt'],
  },
  {
    id: 'accounts',
    title: 'Account management',
    line: 'Turning “there’s a problem” into “here’s exactly what needs to happen next.”',
    detail: 'Requirement gathering, follow-up, coordination between teams, platform testing, issue reporting, execution tracking.',
    items: ['Requirement gathering', 'Client / team communication', 'Task coordination', 'Follow-up', 'Technology coordination', 'Platform testing', 'Issue reporting', 'Execution tracking'],
    projects: ['elhesa', 'skilled'],
  },
  {
    id: 'business',
    title: 'Business',
    line: 'How money moves. How customers move. How teams move. How information moves.',
    detail: 'Exposure to business models, pricing, team structures and growth. Some of it from client work, some from trying to build my own thing.',
    items: ['Business models', 'Pricing', 'Monetization', 'Customer journeys', 'Team structures', 'Growth', 'Operations', 'Partnerships', 'Sales', 'Product thinking'],
    projects: ['studyhub', 'rlvnt', 'booklet'],
  },
  {
    id: 'systems',
    title: 'Systems',
    line: 'Forms, sheets, SOPs, dashboards. Fewer things for people to remember.',
    detail: 'Not software engineering. Structure: where information enters, who owns it next, where it ends up.',
    items: ['Google Forms', 'Google Sheets', 'SOPs', 'Workflows', 'Dashboards', 'Reporting', 'Evaluation systems', 'Pricing calculators', 'Operational templates'],
    projects: ['systems', 'elhesa', 'studyhub'],
  },
  {
    id: 'problems',
    title: 'Problem solving',
    line: 'The thread running through all of it.',
    detail: 'Sometimes the answer is a campaign. Sometimes it’s better communication. Sometimes it’s a new workflow.',
    items: ['Understand', 'Break it down', 'Build', 'Execute', 'Measure', 'Improve'],
    projects: ['bassthalk', 'elhesa', 'studyhub', 'seagate', 'booklet', 'skilled', 'rlvnt', 'systems'],
  },
];

export const process = [
  { n: '01', title: 'Understand', line: 'What’s actually going on. Not what it looks like from the first message.' },
  { n: '02', title: 'Break it down', line: 'Smaller pieces. Clear owners. What depends on what.' },
  { n: '03', title: 'Build', line: 'A campaign, a form, a plan, a sheet. Whatever the problem needs.' },
  { n: '04', title: 'Execute', line: 'Ship it. Follow up. Chase it until it’s done.' },
  { n: '05', title: 'Measure', line: 'What changed. What didn’t. Honest numbers only.' },
  { n: '06', title: 'Improve', line: 'Keep what worked. Fix what didn’t. Run it again.' },
];
