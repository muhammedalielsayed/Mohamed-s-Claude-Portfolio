/**
 * Edit this file to update contact links, portraits and global copy.
 * Replace the YOUR_* placeholders with real values. Nothing else needs to change.
 */
export const site = {
  name: 'Mohamed Ali',
  location: 'Egypt',
  currentRole: 'Account Manager',
  currentCompany: 'ELHESA',
  disciplines: ['Marketing', 'Content', 'Accounts', 'Systems'],
  footerDisciplines: ['Marketing', 'Content', 'Accounts', 'Business', 'Systems'],
  url: 'https://example.com',
  description:
    'Mohamed Ali — I like solving problems. Marketing was just where I started. Marketing, content, accounts, business and systems.',

  contact: {
    email: 'YOUR_EMAIL',
    linkedin: 'YOUR_LINKEDIN',
    instagram: 'YOUR_INSTAGRAM',
  },

  images: {
    hero: '/images/profile/hero.jpg',
    about: '/images/profile/about.jpg',
    headshot: '/images/profile/headshot.jpg',
    casual: '/images/profile/casual.jpg',
    work: '/images/profile/work.jpg',
  },

  nav: [
    { label: 'About', href: '/about' },
    { label: 'Work', href: '/work' },
    { label: 'Experience', href: '/experience' },
    { label: 'Contact', href: '/contact' },
  ],

  secondaryNav: [
    { label: 'Case studies', href: '/case-studies' },
    { label: 'Skills', href: '/skills' },
  ],
};

export type ContactKind = keyof typeof site.contact;

/** Returns a usable href, or null while the value is still a placeholder. */
export function contactHref(kind: ContactKind): string | null {
  const value = site.contact[kind];
  if (!value || value.startsWith('YOUR_')) return null;
  if (kind === 'email') return value.startsWith('mailto:') ? value : `mailto:${value}`;
  return value.startsWith('http') ? value : `https://${value}`;
}
