# Mohamed Ali — Portfolio

Next.js 14 (App Router) · React · TypeScript · Tailwind CSS · Framer Motion

## Run

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

Deploys as-is to Vercel (import the repo, no config needed).

## What to edit (no component changes needed)

| What | Where |
|---|---|
| Email / LinkedIn / Instagram | `data/site.ts` → `contact` (replace `YOUR_EMAIL`, `YOUR_LINKEDIN`, `YOUR_INSTAGRAM`) |
| Portraits | `public/images/profile/` (see `public/images/README.md`) |
| Project screenshots | `public/images/projects/<slug>/` |
| Gallery layouts | `data/projects.ts` → `gallery` |
| Case study copy | `data/projects.ts` |
| Timeline | `data/experience.ts` |
| Skills, tools, "What I work across", "How I work" | `data/skills.ts` |
| "A few numbers" | `data/metrics.ts` |

Contact buttons stay inert until you replace the placeholders.

## Pages

- `/` Home — hero, short story, how I work, what I work across, selected work, numbers, experience, what's next, contact
- `/about` — who I am, how I started, how I learned, what I worked on, how I think, what I'm learning, where I'm going, photos, timeline
- `/work` — case study grid + other accounts
- `/case-studies` — index view
- `/case-studies/[slug]` — 8 case studies
- `/experience` — full editorial timeline
- `/skills` — skills, tools, areas of experience
- `/contact`

## Truth rule (built into the data)

Metric types: `result` (approximate documented), `documented` (exact source data), `target`, `objective`.
Targets and objectives render as outlined numerals with a dashed badge, so they never read as achievements.
Don't add a number to the data unless it's documented.

## Structure

```
app/          pages, layout, globals.css, sitemap, robots
components/   Navbar, Hero, AboutIntro, ProcessSection, WorkAcross, WorkGrid, ProjectCard,
              CaseStudyHero, CaseStudySection, CaseVisual, Gallery, Metric, NumbersSection,
              ExperienceTimeline, SkillsGrid, FutureSection, ContactSection, Footer,
              SmartImage (image + placeholder), Reveal (motion helpers), ScrollProgress
data/         site.ts, projects.ts, experience.ts, skills.ts, metrics.ts
lib/          types.ts
public/images profile/, projects/<slug>/, work/, misc/
```

Motion respects `prefers-reduced-motion`. Keyboard: skip link, visible focus, arrow keys in the "What I work across" tabs, Esc closes the mobile menu.
